drop table jira_tickets_daily;
create table jira_tickets_daily
(
 jira_id integer primary key autoincrement,
 key text,
 url text,
 pre_status text,
 status text,
 assignee text,
 batch_date text,
 reopen_times integer,
 create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);