package com.aiatss.coast.jiratool;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

public class DailyReportParser {

    private static final RestTemplate CALLER = new RestTemplate();

    private static final String COOKIE = "JSESSIONID=1F9B192CB329AA70CB63B800E4A574D9; atlassian.xsrf.token=BLPO-X9DO-QPZ1-F1QE|1b081db57e03a6159873f4d8aba9578e3f9b8b99|lin";

    private static final String BOARD_URL = "http://cangzpwsvn01:8080/rest/greenhopper/1.0/xboard/work/allData.json?rapidViewId=417&_=1503025740913";

    private static final String OUTPUT_FILE = "D:/report/" + new SimpleDateFormat("yyyyMMdd").format(new Date())
            + ".xlsx";

    private static final String ROOT_CAUSE_CATEGORY_ID = "customfield_11702-val";

    private static final String REOPEN_TIME_ID = "customfield_11600-val";

    private static final String[] XLS_HEADER = { "URL", "Status", "Type", "Report To", "Has Solution",
            "Has Root Cause Category", "Root Cause Category", "Has Root Cause", "Has UT result", "Fix Version/s",
            "Reopen Times" };

    private static final Collection<String> STATUS_ID_REVIEW_AND_UT = Collections.singleton("11102");

    private static final Collection<String> STATUS_ID_CONSTRUCTION_DONE = Collections.singleton("10304");

    private static final Collection<String> STATUS_ID_COMPLETED = Collections.singleton("11400");

    private static final Collection<String> STATUS_ID_SIT = Arrays.asList("10405", "10201", "5");

    private static final Collection<String> STATUS_ID_SIT_REVIEW = Collections.singleton("11900");

    private static String getOwnerByName(String name) {
        if ("Case360 - Miles".equals(name)) {
            return "Miles";
        }
        else if ("CM&Correspondence - Terry".equals(name)) {
            return "Terry";
        }
        else if ("Report - Alex".equals(name)) {
            return "Alex";
        }
        else {
            return "Issac/Foison";
        }
    }

    private static final Collection<String> STATUS_ALL = new ArrayList<>();

    static {
        STATUS_ALL.addAll(STATUS_ID_REVIEW_AND_UT);
        STATUS_ALL.addAll(STATUS_ID_CONSTRUCTION_DONE);
        STATUS_ALL.addAll(STATUS_ID_COMPLETED);
        STATUS_ALL.addAll(STATUS_ID_SIT);
        STATUS_ALL.addAll(STATUS_ID_SIT_REVIEW);
    }

    public static void main(String[] args) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Sheet1");
        int rowIndex = 0;
        XSSFRow row = sheet.createRow(rowIndex++);
        int cellIndex = 0;
        for (String headerCell : XLS_HEADER) {
            XSSFCell cell = row.createCell(cellIndex++);
            cell.setCellValue(headerCell);
        }

        Map<String, Object> boardMap = getBoard();

        Map<Integer, String> issueIdNameMap = new HashMap<>();
        Collection<Map<String, Object>> swimlanes = (Collection<Map<String, Object>>) ((Map<String, Object>) ((Map<String, Object>) boardMap
                .get("swimlanesData")).get("customSwimlanesData")).get("swimlanes");
        for (Map<String, Object> swimlaneMap : swimlanes) {
            Collection<Integer> issueIds = (Collection<Integer>) swimlaneMap.get("issueIds");
            String name = swimlaneMap.get("name").toString();
            for (Integer issueId : issueIds) {
                issueIdNameMap.put(issueId, name);
            }
        }

        List<Map<String, Object>> taskList = getTasksFromBoard(boardMap).stream()
                .filter(e -> STATUS_ALL.contains(e.get("statusId").toString()))
                .sorted((e1, e2) -> e1.get("key").toString().compareTo(e2.get("key").toString())).map(e -> {
                    e.put("url", "http://cangzpwsvn01:8080/browse/" + (String) e.get("key"));
                    return e;
                }).collect(Collectors.toList());

        for (Map<String, Object> taskMap : taskList) {
            JiraPage jiraPage = new JiraPage(taskMap.get("url").toString());
            cellIndex = 0;
            XSSFRow dataRow = sheet.createRow(rowIndex++);
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.getUrl());
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.getStatus());
            dataRow.createCell(cellIndex++).setCellValue(issueIdNameMap.get((Integer) taskMap.get("id")));
            dataRow.createCell(cellIndex++).setCellValue(
                    getOwnerByName(issueIdNameMap.get((Integer) taskMap.get("id")))); // report to
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.hasSolution ? "Y" : "N");
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.hasRootCauseCategory ? "Y" : "N");
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.rootCauseCategory);
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.hasRootCause ? "Y" : "N");

            // Has UT result
            String statusId = taskMap.get("statusId").toString();
            if (isStatusIdNeedUT(statusId)) {
                dataRow.createCell(cellIndex++).setCellValue(
                        (jiraPage.hasAttachment && jiraPage.hasSITPASS) ? "Y" : "N");
            }
            else {
                dataRow.createCell(cellIndex++).setCellValue("N/A");
            }

            // fix version
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.getFixVersion());

            // reopen times
            dataRow.createCell(cellIndex++).setCellValue(jiraPage.getReopenTimes());
        }

        workbook.write(new FileOutputStream(OUTPUT_FILE));
        workbook.close();

    }

    private static boolean isStatusIdNeedUT(String statusId) {
        return "11400".equals(statusId) || "10405".equals(statusId) || "10201".equals(statusId) || "5".equals(statusId)
                || "11900".equals(statusId);
    }

    private static String getHttpBody(String url) {
        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(getHeader());
        return CALLER.exchange(url, HttpMethod.GET, httpEntity, String.class).getBody();
    }

    private static Map<String, Object> getBoard() {
        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(getHeader());
        return CALLER.exchange(BOARD_URL, HttpMethod.GET, httpEntity, Map.class).getBody();
    }

    private static Collection<Map<String, Object>> getTasksFromBoard(Map<String, Object> board) {
        return (Collection<Map<String, Object>>) ((Map<String, Object>) board.get("issuesData")).get("issues");
    }

    private static MultiValueMap<String, String> getHeader() {
        MultiValueMap<String, String> header = new LinkedMultiValueMap();
        header.set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
        header.set("Accept-Encoding", "deflate");
        header.set("Accept-Language", "zh-CN,en-US;q=0.8,en;q=0.6,zh;q=0.4");
        header.set("Cache-Control", "no-cache");
        header.set("Connection", "keep-alive");
        header.set("Cookie", COOKIE);
        header.set("Host", "cangzpwsvn01:8080");
        header.set("Pragma", "no-cache");
        header.set("Upgrade-Insecure-Requests", "1");
        header.set("User-Agent",
                "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36");
        return header;
    }

    static class JiraPage {
        private boolean hasSolution, hasRootCause, hasRootCauseCategory, hasAttachment, hasSITPASS;

        private String url, status, rootCauseCategory = "N/A", fixVersion, reopenTimes;

        Document document;

        public JiraPage(String url) {
            this.url = url;
            this.document = Jsoup.parse(getHttpBody(url));
            parseDoc();
        }

        private void parseDoc() {
            Elements elements = this.document.getElementsByClass("name");
            for (Element element : elements) {
                String text = element.text();
                if ("Root Cause:".equals(text)) {
                    this.hasRootCause = true;
                }
                else if ("Root Cause Category:".equals(text)) {
                    this.hasRootCauseCategory = true;
                    this.rootCauseCategory = this.document.getElementById(ROOT_CAUSE_CATEGORY_ID).text();
                }
                else if ("Solution:".equals(text)) {
                    this.hasSolution = true;
                }
            }
            elements = this.document
                    .getElementsByClass(" jira-issue-status-lozenge aui-lozenge jira-issue-status-lozenge-yellow jira-issue-status-lozenge-indeterminate jira-issue-status-lozenge-max-width-medium");
            status = elements.get(0).text();

            elements = this.document.getElementsByClass("toggle-title");
            for (Element eLement : elements) {
                if ("Attachments".equals(eLement.text())) {
                    hasAttachment = true;
                    Elements attachTitleEle = this.document.getElementsByClass("attachment-title");
                    for (Element attachTitle : attachTitleEle) {
                        String attachmentTitle = attachTitle.text().toLowerCase();
                        if (attachmentTitle.contains("sit") && attachmentTitle.contains("pass")) {
                            hasSITPASS = true;
                            break;
                        }
                        else if (attachmentTitle.contains("test") && attachmentTitle.contains("pass")) {
                            hasSITPASS = true;
                            break;
                        }
                    }
                    break;
                }
            }

            this.fixVersion = this.document.getElementById("fixVersions-field").text();

            Element reopenEle = this.document.getElementById(REOPEN_TIME_ID);
            if (reopenEle != null) {
                this.reopenTimes = reopenEle.text();
            }
        }

        public String getReopenTimes() {
            return reopenTimes;
        }

        public void setReopenTimes(String reopenTimes) {
            this.reopenTimes = reopenTimes;
        }

        public String getFixVersion() {
            return fixVersion;
        }

        public void setFixVersion(String fixVersion) {
            this.fixVersion = fixVersion;
        }

        public String getUrl() {
            return url;
        }

        public String getStatus() {
            return status;
        }

        public boolean isHasSolution() {
            return hasSolution;
        }

        public void setHasSolution(boolean hasSolution) {
            this.hasSolution = hasSolution;
        }

        public boolean isHasRootCause() {
            return hasRootCause;
        }

        public void setHasRootCause(boolean hasRootCause) {
            this.hasRootCause = hasRootCause;
        }

        public boolean isHasRootCauseCategory() {
            return hasRootCauseCategory;
        }

        public void setHasRootCauseCategory(boolean hasRootCauseCategory) {
            this.hasRootCauseCategory = hasRootCauseCategory;
        }

        public boolean isHasAttachment() {
            return hasAttachment;
        }

        public void setHasAttachment(boolean hasAttachment) {
            this.hasAttachment = hasAttachment;
        }

        public String getRootCauseCategory() {
            return rootCauseCategory;
        }

        public void setRootCauseCategory(String rootCauseCategory) {
            this.rootCauseCategory = rootCauseCategory;
        }
    }
}
