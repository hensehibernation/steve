package com.aiatss.coast.jiratool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiraToolApplication {

    public static void main(String[] args) {
        SpringApplication.run(JiraToolApplication.class, args);
    }

}
