package com.aiatss.coast.jiratool.bean;

/**
 * Created by ASNPHPX on 8/29/2017.
 */
public enum Status {
    // CONSTRUCTION- DONE, SYSTEMTEST - REVIEW
    REQUIREMENT_DOING(1), READY_FOR_CONSTRUCTION(2), CONSTRUCTION_DOING(3), CONSTRUCTION_REVIEW(4), CONSTRUCTION_DONE(5),
    READY_FOR_ST_PROMOTION(6), RESOLVED(7), SYSTEMTEST_TODO(7), SYSTEMTEST_DOING(7), SYSTEMTEST_REVIEW(8);

    int code;

    Status(int code) {
        this.code = code;
    }

    public int getCode() {
        return this.code;
    }

    public static Status getStatus(String status) {
        if (status != null) {
            status = status.toUpperCase();
            if (status.contains("REQUIREMENT") && status.contains("DOING")) {
                return REQUIREMENT_DOING;
            } else if (status.contains("READY") && status.contains("FOR") && status.contains("CONSTRUCTION")) {
                return READY_FOR_CONSTRUCTION;
            } else if (status.contains("CONSTRUCTION") && status.contains("DOING")) {
                return CONSTRUCTION_DOING;
            } else if (status.contains("CONSTRUCTION") && status.contains("REVIEW")) {
                return CONSTRUCTION_REVIEW;
            } else if (status.contains("CONSTRUCTION") && status.contains("DONE")) {
                return CONSTRUCTION_DONE;
            } else if (status.contains("READY") && status.contains("FOR") && status.contains("ST") && status.contains("PROMOTION")) {
                return READY_FOR_ST_PROMOTION;
            } else if (status.contains("RESOLVED")) {
                return RESOLVED;
            } else if (status.contains("SYSTEMTEST") && status.contains("TODO")) {
                return SYSTEMTEST_TODO;
            } else if (status.contains("SYSTEMTEST") && status.contains("DOING")) {
                return SYSTEMTEST_DOING;
            } else if (status.contains("SYSTEMTEST") && status.contains("REVIEW")) {
                return SYSTEMTEST_REVIEW;
            }
        }
        throw new IllegalArgumentException("Cannot parse status: " + status);
    }
}
