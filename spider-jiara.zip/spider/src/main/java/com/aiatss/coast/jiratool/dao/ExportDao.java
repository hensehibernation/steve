package com.aiatss.coast.jiratool.dao;

import com.aiatss.coast.jiratool.bean.JiraTicketsDaily;
import com.aiatss.coast.jiratool.bean.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by ASNPHPX on 8/29/2017.
 */
@Repository
public class ExportDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final SimpleDateFormat BATCH_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");

    public void insertJiraTickets(List<JiraTicketsDaily> jiraTicketsDailyList) {
        if (jiraTicketsDailyList != null) {
            String sql = "INSERT INTO jira_tickets_daily(key, url, pre_status_code, pre_status, status_code, status, assignee, batch_date, reopen_times) " +
                    "VALUES (?,?,?,?,?,?,?,?,?)";
            List<Object[]> paramsList = new ArrayList<>();
            String batchDate = BATCH_DATE_FORMAT.format(new Date());
            for (JiraTicketsDaily jiraTicketsDaily : jiraTicketsDailyList) {
                Object[] aParams = new Object[9];
                int index = 0;
                aParams[index++] = jiraTicketsDaily.getKey();
                aParams[index++] = jiraTicketsDaily.getUrl();
                aParams[index++] = jiraTicketsDaily.getPreStatus() == null ? null : jiraTicketsDaily.getPreStatus().getCode();
                aParams[index++] = jiraTicketsDaily.getPreStatus() == null ? null : jiraTicketsDaily.getPreStatus().name();
                aParams[index++] = jiraTicketsDaily.getStatus().getCode();
                aParams[index++] = jiraTicketsDaily.getStatus().name();
                aParams[index++] = jiraTicketsDaily.getAssignee();
                aParams[index++] = batchDate;
                aParams[index++] = jiraTicketsDaily.getReopenTimes();
                paramsList.add(aParams);
            }
            jdbcTemplate.batchUpdate(sql, paramsList);
        }
    }

    public int getBatchDateCount(String batchDate) {
        String sql = "SELECT COUNT(*) FROM jira_tickets_daily WHERE batch_date = ?";
        return jdbcTemplate.queryForObject(sql, Integer.class, batchDate);
    }

    public List<JiraTicketsDaily> getPreBatchDateData() {
        String sql = "SELECT * FROM jira_tickets_daily WHERE batch_date = (SELECT max(batch_date) FROM jira_tickets_daily WHERE batch_date <> (SELECT max(batch_date) FROM jira_tickets_daily))";
        return jdbcTemplate.query(sql, new RowMapper<JiraTicketsDaily>() {
            @Override
            public JiraTicketsDaily mapRow(ResultSet rs, int rowNum) throws SQLException {
                return getJiraTicketsDaily(rs);
            }
        });
    }

    public List<JiraTicketsDaily> getMaxBatchDateData() {
        String sql = "SELECT * FROM jira_tickets_daily WHERE batch_date = (SELECT max(batch_date) FROM jira_tickets_daily)";
        return jdbcTemplate.query(sql, new RowMapper<JiraTicketsDaily>() {
            @Override
            public JiraTicketsDaily mapRow(ResultSet rs, int rowNum) throws SQLException {
                return getJiraTicketsDaily(rs);
            }
        });
    }

    private JiraTicketsDaily getJiraTicketsDaily(ResultSet rs) throws SQLException {
        JiraTicketsDaily jiraTicketsDaily = new JiraTicketsDaily();
        jiraTicketsDaily.setKey(rs.getString("key"));
        jiraTicketsDaily.setUrl(rs.getString("url"));
        String preStatus = rs.getString("pre_status");
        if (preStatus != null) {
            jiraTicketsDaily.setPreStatus(Status.getStatus(preStatus));
        }
        jiraTicketsDaily.setStatus(Status.getStatus(rs.getString("status")));
        jiraTicketsDaily.setAssignee(rs.getString("assignee"));
        jiraTicketsDaily.setBatchDate(rs.getString("batch_date"));
        jiraTicketsDaily.setReopenTimes(rs.getString("reopen_times"));
        return jiraTicketsDaily;
    }
}
