package com.aiatss.coast.jiratool.utils;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * Created by ASNPHPX on 8/29/2017.
 */
public class HttpUtils {

    private static final RestTemplate CALLER = new RestTemplate();

    public static Map<String, Object> getRest(String cookie, String url) {
        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(constructHeaders(cookie));
        return CALLER.exchange(url, HttpMethod.GET, httpEntity, Map.class).getBody();
    }

    public static String getHttpBody(String cookie, String url) {
        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(constructHeaders(cookie));
        return CALLER.exchange(url, HttpMethod.GET, httpEntity, String.class).getBody();
    }

    private static MultiValueMap<String, String> constructHeaders(String cookie) {
        MultiValueMap<String, String> header = new LinkedMultiValueMap();
        header.set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
        header.set("Accept-Encoding", "deflate");
        header.set("Accept-Language", "zh-CN,en-US;q=0.8,en;q=0.6,zh;q=0.4");
        header.set("Cache-Control", "no-cache");
        header.set("Connection", "keep-alive");
        header.set("Cookie", cookie);
        header.set("Host", "cangzpwsvn01:8080");
        header.set("Pragma", "no-cache");
        header.set("Upgrade-Insecure-Requests", "1");
        header.set("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36");
        return header;
    }
}
