package com.aiatss.coast.jiratool.services;

import com.aiatss.coast.jiratool.bean.JiraTicketsDaily;
import com.aiatss.coast.jiratool.dao.ExportDao;
import com.aiatss.coast.jiratool.utils.HttpUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by ASNPHPX on 8/29/2017.
 */
@Service
public class ExportServiceImpl implements ExportService {

    @Autowired
    private ExportDao exportDao;

    private static final String URL_TICKET_LIST = "http://cangzpwsvn01:8080/secure/views/bulkedit/BulkEdit1!default.jspa?reset=true&tempMax=48";

    private static final String BOARD_URL = "http://cangzpwsvn01:8080/rest/greenhopper/1.0/xboard/work/allData.json?rapidViewId=417&_=1503025740913";

    private static final String DATA_ISSUE_KEY = "data-issue-key";

    private static final SimpleDateFormat BATCH_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");

    private static final String[] XLS_HEADER = {"url", "pre status", "status", "assignee", "reopen times"};

    @Override
    public List<String[]> export(String cookie) {
        prepareData(cookie);

        Map<String, JiraTicketsDaily> preJiraTicketDailyMap = exportDao.getPreBatchDateData().stream().collect(Collectors.toMap(JiraTicketsDaily::getKey, e -> e));
        Map<String, JiraTicketsDaily> jiraTicketDailyMap = exportDao.getMaxBatchDateData().stream().collect(Collectors.toMap(JiraTicketsDaily::getKey, e -> e));

        List<JiraTicketsDaily> fixedList = new ArrayList<>();
        List<JiraTicketsDaily> newList = new ArrayList<>();
        List<JiraTicketsDaily> reopenList = new ArrayList<>();

        for (String key : preJiraTicketDailyMap.keySet()) {
            if (!jiraTicketDailyMap.containsKey(key)) {
                fixedList.add(preJiraTicketDailyMap.get(key));
            }
        }

        for (String key : jiraTicketDailyMap.keySet()) {
            JiraTicketsDaily jiraObj = jiraTicketDailyMap.get(key);
            if (!preJiraTicketDailyMap.containsKey(key)) {
                newList.add(jiraObj);
            }
            if (jiraObj.getPreStatus() != null && jiraObj.getPreStatus().getCode() > jiraObj.getStatus().getCode()) {
                reopenList.add(jiraObj);
            } else if (jiraObj.getReopenTimes() != null
                    && !jiraObj.getReopenTimes().trim().equalsIgnoreCase("")
                    && Integer.parseInt(jiraObj.getReopenTimes()) > 0) {
                reopenList.add(jiraObj);
            }
        }

        List<String[]> dataList = new ArrayList<>();

        // completed tickets
        dataList.add(new String[]{"Completed: "});
        dataList.add(XLS_HEADER);
        for (JiraTicketsDaily jiraTicketsDaily : fixedList) {
            dataList.add(getData(jiraTicketsDaily));
        }

        dataList.add(new String[]{});

        // new tickets
        dataList.add(new String[]{"New: "});
        dataList.add(XLS_HEADER);
        for (JiraTicketsDaily jiraTicketsDaily : newList) {
            dataList.add(getData(jiraTicketsDaily));
        }

        dataList.add(new String[]{});

        // reopen tickets
        dataList.add(new String[]{"Reopen: "});
        dataList.add(XLS_HEADER);
        for (JiraTicketsDaily jiraTicketsDaily : reopenList) {
            dataList.add(getData(jiraTicketsDaily));
        }

        return dataList;
    }

    private String[] getData(JiraTicketsDaily jiraTicketsDaily) {
        if (jiraTicketsDaily == null) {
            return new String[0];
        } else {
            return new String[]{jiraTicketsDaily.getUrl(), jiraTicketsDaily.getPreStatus() == null ? null : jiraTicketsDaily.getPreStatus().name(), jiraTicketsDaily.getStatus().name(), jiraTicketsDaily.getAssignee(), jiraTicketsDaily.getReopenTimes()};
        }
    }

    private synchronized void prepareData(String cookie) {
        String batchDate = BATCH_DATE_FORMAT.format(new Date());
        if (exportDao.getBatchDateCount(batchDate) > 0) {
            System.out.println(batchDate + " data exists, quit.");
        } else {
            System.out.println(batchDate + " data doesn't exist. Preparing...");
            List<JiraTicketsDaily> jiraTicketsDailyList = new ArrayList<>();
            //Collection<String> keys = parseTicketList(cookie);
            Collection<String> keys = ((Collection<Map<String, Object>>) ((Map<String, Object>) HttpUtils.getRest(cookie, BOARD_URL).get("issuesData")).get("issues"))
                    .stream().map(e -> e.get("key").toString()).collect(Collectors.toList());

            Map<String, JiraTicketsDaily> preJiraTicketDailyMap = exportDao.getMaxBatchDateData().stream().collect(Collectors.toMap(JiraTicketsDaily::getKey, e -> e));

            for (String key : keys) {
                JiraTicketsDaily jiraTicketsDaily = new JiraTicketsDaily(key, cookie);
                if (preJiraTicketDailyMap.containsKey(key)) {
                    jiraTicketsDaily.setPreStatus(preJiraTicketDailyMap.get(key).getStatus());
                }
                jiraTicketsDailyList.add(jiraTicketsDaily);
            }
            System.out.println("Parse page completed, total: " + jiraTicketsDailyList.size());

            exportDao.insertJiraTickets(jiraTicketsDailyList);
            System.out.println("Insert DB completed");
        }
    }

    private Collection<String> parseTicketList(String cookie) {
        String body = HttpUtils.getHttpBody(cookie, URL_TICKET_LIST);
        Document document = Jsoup.parse(body);
        return document.getElementsByAttribute(DATA_ISSUE_KEY).stream().map(e -> e.attr(DATA_ISSUE_KEY)).collect(Collectors.toSet());
    }

}
