package com.aiatss.coast.jiratool.services;

import java.util.List;

/**
 * Created by ASNPHPX on 8/29/2017.
 */
public interface ExportService {
    List<String[]> export(String cookie);
}
