package com.aiatss.coast.jiratool.bean;

import com.aiatss.coast.jiratool.utils.HttpUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Created by ASNPHPX on 8/29/2017.
 */
public class JiraTicketsDaily {
    private String key;
    private String url;
    private Status preStatus;
    private Status status;
    private String assignee;
    private String fixVersion;
    private String batchDate;
    private String reopenTimes;

    private Document document;

    public JiraTicketsDaily() {

    }

    public JiraTicketsDaily(String key, String cookie) {
        this.key = key;
        this.url = "http://cangzpwsvn01:8080/browse/" + key;
        this.document = Jsoup.parse(HttpUtils.getHttpBody(cookie, url));
        parseDoc();
    }

    private void parseDoc() {
        Elements elements = this.document.getElementsByClass(" jira-issue-status-lozenge aui-lozenge jira-issue-status-lozenge-yellow jira-issue-status-lozenge-indeterminate jira-issue-status-lozenge-max-width-medium");

        System.out.println("parsing " + key);
        this.status = Status.getStatus(elements.get(0).text());

        this.fixVersion = this.document.getElementById("fixVersions-field").text();

        Element reopenEle = this.document.getElementById("customfield_11600-val");
        if(reopenEle != null) {
            this.reopenTimes = reopenEle.text();
        }

        assignee = this.document.getElementById("assignee-val").text();
    }

    public String getBatchDate() {
        return batchDate;
    }

    public void setBatchDate(String batchDate) {
        this.batchDate = batchDate;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Status getPreStatus() {
        return preStatus;
    }

    public void setPreStatus(Status preStatus) {
        this.preStatus = preStatus;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getFixVersion() {
        return fixVersion;
    }

    public void setFixVersion(String fixVersion) {
        this.fixVersion = fixVersion;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getReopenTimes() {
        return reopenTimes;
    }

    public void setReopenTimes(String reopenTimes) {
        this.reopenTimes = reopenTimes;
    }
}
