package com.aiatss.coast.jiratool.controller;

import com.aiatss.coast.jiratool.services.ExportService;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by ASNPHPX on 8/29/2017.
 */
@RestController
public class ExportController {

    @Autowired
    private ExportService exportService;

    private static final SimpleDateFormat OUTPUT_FORMAT = new SimpleDateFormat("yyyyMMdd");

    @RequestMapping(path = "/export", method = RequestMethod.POST)
    public void export(@RequestParam String cookie, HttpServletResponse response) throws IOException {
        response.setContentType("application/x-msdownload");
        response.setHeader("Content-Disposition", "attachment;filename=" + ("jira_report_" + OUTPUT_FORMAT.format(new Date()) + ".xlsx"));

        List<String[]> dataList = exportService.export(cookie);

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Sheet1");
        sheet.setDefaultColumnWidth(27);
        int rowIndex = 0;
        for (String[] rowData : dataList) {
            XSSFRow row = sheet.createRow(rowIndex++);
            int cellIndex = 0;
            for (String cellData : rowData) {
                XSSFCell cell = row.createCell(cellIndex++);
                cell.setCellValue(cellData);
            }
        }

        workbook.write(response.getOutputStream());
        workbook.close();
    }
}
