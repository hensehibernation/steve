package test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.icss.henry.dao.IComment;
import com.icss.henry.vo.Comment;

public class CommentDaoImplTest {
	private ApplicationContext applicationContext;
	private IComment cmt;
	@Before
	public void before(){
		applicationContext = 
				new ClassPathXmlApplicationContext(new String[]{"applicationContext.xml"});
		cmt=(IComment)applicationContext.getBean("commentDaoImpl"); 
	}
	@Test
	public void  addTest(){
		
		List<Comment> list =new ArrayList();
		Random random=new Random();
		int a[]={3,5,6};
		int b=6;
		Comment comment1=new Comment(1," 很好，很满意~",new Date(),a[random.nextInt(3)],b);
		Comment comment2=new Comment(2," 一般般~",new Date(),a[random.nextInt(3)],b);
		Comment comment3=new Comment(3,"不知道为什么，就是想给个差评",new Date(),a[random.nextInt(3)],b);
		list.add(comment1);
		list.add(comment2);
		list.add(comment3);
		//int a[]={1,2,3};
		for(int i=0;i<20;i++){
			System.out.println(list.get(random.nextInt(3)));
			cmt.add((Comment)list.get(random.nextInt(3)));
		}
	}
}
