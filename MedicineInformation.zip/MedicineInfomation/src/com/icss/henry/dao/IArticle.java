package com.icss.henry.dao;

import java.util.List;

import com.icss.henry.common.BaseInfo;
import com.icss.henry.vo.Article;

public interface IArticle {
	int add(Article article);
	int delete(int ar_id);
	int update(Article article);
	int updateViewNum(int ar_viewNum,int ar_id);
	List<Article> queryAll();
	List<Article> querySug();
	Article  searchById(int ar_id);
	List<Article> queryById(int ar_id);
	List<Article> queryByKinds(int ar_id);
//	List<Article> queryByKindsSug(int ar_id);
	List<Article> pageAll(int pageRow,int pageRowMax);
	List<Article> searchBystr(String ar_str);
	
}
