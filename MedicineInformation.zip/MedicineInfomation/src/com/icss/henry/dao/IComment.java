package com.icss.henry.dao;

import java.util.List;

import com.icss.henry.vo.Comment;

public interface IComment {
	int add(Comment comment);
	int delete(int comment_id);
	int update(Comment comment);
	List<Comment> queryAll();
	Comment  searchById(int comment_id);
	List<Comment> queryByGoodsId(int goods_id);
	List<Comment> queryByKinds(int comment_id);
	List<Comment> searchBystr(String comment_str);
}
