package com.icss.henry.dao;

import java.util.List;

import com.icss.henry.vo.Goods;

public interface IGoods {
	int add(Goods goods);
	int delete(int goods_id);
	int update(Goods goods);
	int updateSale(int goods_sale,int goods_id);
	List<Goods> queryAll();
	List<Goods> querySug();
	Goods  searchById(int goods_id);
	List<Goods>  queryAllByUserId(int goods_user_id);
	List<Goods> queryByKinds(int goods_id);
	List<Goods> queryByKindsSug(int goods_id);
	List<Goods> pageAll(int pageRow,int pageRowMax);
	List<Goods> searchBystr(String goods_str);
}
