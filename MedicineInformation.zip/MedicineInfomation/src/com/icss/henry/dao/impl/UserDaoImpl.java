package com.icss.henry.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.icss.henry.dao.IUser;
import com.icss.henry.vo.User;


@Repository
public class UserDaoImpl implements IUser{
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	@Override
	public int add(User user) {
		// TODO Auto-generated method stub
		return this.jdbcTemplate.update("insert into user(user_email,user_pwd,user_name,user_kinds,"
				+ "user_tel,user_sex,user_address,user_birthday) values(?,?,?,1,?,?,?,?)",
				user.getUser_email(),user.getUser_pwd(),user.getUser_name(),user.getUser_tel(),user.isUser_sex(),user.getUser_address(),
				user.getUser_birthday());
	}
	
	public int addMerchant(User user){
		return this.jdbcTemplate.update("insert into user(user_email,user_pwd,user_name,user_kinds,"
				+ "user_tel,user_sex,user_address,user_birthday,user_shop_name) values(?,?,?,2,?,?,?,?,?)",
				user.getUser_email(),user.getUser_pwd(),user.getUser_name(),user.getUser_tel(),user.isUser_sex(),user.getUser_address(),
				user.getUser_birthday(),user.getUser_shop_name());
	}
	@Override
	public int update(User user) {
		// TODO Auto-generated method stub
		String sql="update user set user_name=?,user_pwd=?,user_tel=?,user_sex=?,user_address=?,user_birthday=?,user_shop_name=? "+
				" where  user_id=?";
		return this.jdbcTemplate.update(sql,user.getUser_name(),user.getUser_pwd(),user.getUser_tel(),
				user.isUser_sex(),user.getUser_address(),user.getUser_birthday(),user.getUser_shop_name(),
				user.getUser_id());
	}

	@Override
	public int delete(int user_id) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public User searchByEmail(String user_email,String user_pwd,int user_kinds){
		
		String sql ="select * from user where user_email=? and user_pwd=? and user_kinds=?";
		Object[] args = new Object[] {user_email,user_pwd,user_kinds};
		List<User> vo =  this.jdbcTemplate.query(sql,args,new RowMapper<User>(){
					@Override
					public User mapRow(ResultSet rs, int index)throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
		if(vo.isEmpty())
			return null;
		return (User)vo.get(0);  

	}
	public User load(ResultSet rs) throws SQLException{
		User user = new User();
		user.setUser_id(rs.getInt("user_id"));
		user.setUser_kinds(rs.getInt("user_kinds"));
		user.setUser_name(rs.getString("user_name"));
		user.setUser_pwd(rs.getString("user_pwd"));
		user.setUser_address(rs.getString("user_address"));
		user.setUser_birthday(rs.getString("user_birthday"));
		user.setUser_sex(rs.getBoolean("user_sex"));
		user.setUser_tel(rs.getString("user_tel"));
		user.setUser_email(rs.getString("user_email"));
		user.setUser_shop_name(rs.getString("user_shop_name"));
		return user;
	}
	@Override
	public List<User> search(String str) {
		// TODO Auto-generated method stub
		String sql="select * from user where user_name like ? ";
		String newstr="%"+str+"%";
		Object[] args=new Object[]{newstr};
		return this.jdbcTemplate.query(sql,args,new RowMapper<User>(){

			@Override
			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
			
		});
	}

	@Override
	public List<User> queryAll() {
		// TODO Auto-generated method stub
		String sql="select * from user where user_kinds=1 or user_kinds=2";
		return this.jdbcTemplate.query(sql, new RowMapper<User>(){

			@Override
			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
			
		});
	}

	@Override
	public User searchName(String user_email) {
		// TODO Auto-generated method stub
		String sql ="select * from user where user_email=?";
		Object[] args = new Object[] {user_email};
		List<User> vo =  this.jdbcTemplate.query(sql,args,new RowMapper<User>(){
					@Override
					public User mapRow(ResultSet rs, int index)throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
		if(vo.isEmpty())
			return null;
		return (User)vo.get(0);  

	}
	
	@Override
	public User queryByEmail(String user_email) {
		// TODO Auto-generated method stub
		String sql ="select * from user where user_email=?";
		Object[] args = new Object[] {user_email};
		List<User> vo =  this.jdbcTemplate.query(sql,args,new RowMapper<User>(){
					@Override
					public User mapRow(ResultSet rs, int index)throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
		if(vo.isEmpty())
			return null;
		return (User)vo.get(0);  

	}

	@Override
	public User searchById(int user_id) {
		String sql ="select * from user where user_id=?";
		Object[] args = new Object[] {user_id};
		List<User> vo =  this.jdbcTemplate.query(sql,args,new RowMapper<User>(){
					@Override
					public User mapRow(ResultSet rs, int index)throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
		if(vo.isEmpty())
			return null;
		return (User)vo.get(0);
	}

}
