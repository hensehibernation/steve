package com.icss.henry.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.icss.henry.dao.IDrug;
import com.icss.henry.vo.Drug;
import com.icss.henry.vo.User;

@Repository
public class DrugDaoImpl implements	IDrug{
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * 添加药品信息
	 */
	@Override
	public int add(Drug drug) {
		// TODO Auto-generated method stub
		return this.jdbcTemplate.update("insert into drug(dr_name,dr_kinds,dr_msg,"
				+ "dr_img,dr_fileName,dr_filePath) values (?,?,?,?,?,?)",drug.getDr_name(),drug.getDr_kinds(),
				drug.getDr_msg(),drug.getDr_img(),drug.getDr_fileName(),drug.getDr_filePath());
	}

	/**
	 * 删除药品信息
	 * 	@Override
	 */
	public int delete(int dr_id) {
		// TODO Auto-generated method stub
		System.out.println("正在删除~");
		String sql="delete from drug where dr_id=?";
		return this.jdbcTemplate.update(sql,dr_id);
	}

	/**
	 * 更新中药信息
	 */
	@Override
	public int update(Drug drug) {
		// TODO Auto-generated method stub
		return  this.jdbcTemplate.update("update drug set dr_name=?,dr_kinds=?,dr_msg=?,dr_img=?,dr_fileName=?,dr_filePath=? where dr_id=?",drug.getDr_name(),
				drug.getDr_kinds(),drug.getDr_msg(),drug.getDr_img(),drug.getDr_fileName(),drug.getDr_filePath(),drug.getDr_id());
	}

	public Drug load(ResultSet rs) throws SQLException{
		Drug drug = new Drug();
		drug.setDr_id(rs.getInt("dr_id"));
		drug.setDr_kinds(rs.getInt("dr_kinds"));
		drug.setDr_name(rs.getString("dr_name"));
		drug.setDr_img(rs.getString("dr_img"));
		drug.setDr_msg(rs.getString("dr_msg"));
		drug.setDr_fileName(rs.getString("dr_fileName"));
		drug.setDr_filePath(rs.getString("dr_filePath"));
		return drug;
	}
	/**
	 * 查询所有中药
	 */
	@Override
	public List<Drug> queryAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from drug", 
				new RowMapper<Drug>(){
			@Override
			public Drug mapRow(ResultSet rs, int index)throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
		}
		);
	}
	/**
	 * 推荐中药
	 */
	@Override
	public List<Drug> querySug() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select* from drug ORDER BY dr_id limit 4 ", 
				new RowMapper<Drug>(){
			@Override
			public Drug mapRow(ResultSet rs, int index)throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
		}
		);
	}
	/**
	 * 按照中药种类查询
	 * @param ar_kinds
	 * @return
	 */
	public List<Drug> queryByKinds(int dr_kinds){
		String sql="select * from drug where dr_kinds=?";
		Object[] args=new Object[]{dr_kinds};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Drug>(){

					@Override
					public Drug mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}
	/**
	 * 按照中药ID查询
	 * @param ar_kinds
	 * @return
	 */
	public List<Drug> queryById(int dr_id){
		String sql="select * from drug where dr_id=?";
		Object[] args=new Object[]{dr_id};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Drug>(){

					@Override
					public Drug mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}

	@Override
	public List<Drug> pageAll(int pageRow,int pageRowMax) {
		// TODO Auto-generated method stub
		String sql="select * from Drug limit ?,?";
		Object[] args=new Object[]{(pageRow-1)*pageRowMax,pageRowMax};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Drug>(){

					@Override
					public Drug mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}

	@Override
	public Drug searchById(int dr_id) {

		String sql ="select * from drug where dr_id=?";
		Object[] args = new Object[] {dr_id};
		List<Drug> drug =  this.jdbcTemplate.query(sql,args,new RowMapper<Drug>(){
					@Override
					public Drug mapRow(ResultSet rs, int index)throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
		if(drug.isEmpty())
			return null;
		return (Drug)drug.get(0);
	}
	
	/**
	 * 按照搜索内容查询中药信息
	 * @param dr_kinds
	 * @return
	 */
	public List<Drug> searchBystr(String dr_str){
		String sql="select * from drug where dr_name like ?  ";
		String newstr="%"+dr_str+"%";
		Object[] args=new Object[]{newstr};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Drug>(){

					@Override
					public Drug mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}
	

	
}
