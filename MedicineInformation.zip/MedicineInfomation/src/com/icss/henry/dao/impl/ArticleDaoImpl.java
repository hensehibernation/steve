package com.icss.henry.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.icss.henry.dao.IArticle;
import com.icss.henry.vo.Article;
import com.icss.henry.vo.User;

@Repository
public class ArticleDaoImpl implements	IArticle{
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int add(Article article) {
		// TODO Auto-generated method stub
		return this.jdbcTemplate.update("insert into article(ar_kinds,ar_title,ar_img,"
				+ "ar_content,ar_fileName,ar_user,ar_filePath,ar_time) values (?,?,?,?,?,?,?,SYSDATE())",article.getAr_kinds(),article.getAr_title(),article.getAr_img(),article.getAr_content(),article.getAr_fileName(),article.getAr_user(),article.getAr_filePath());
	}

	/**
	 * 删除文章
	 * 	@Override
	 */
	public int delete(int ar_id) {
		// TODO Auto-generated method stub
		System.out.println("正在删除~");
		String sql="delete from article where ar_id=?";
		return this.jdbcTemplate.update(sql,ar_id);
	}

	/**
	 * 更新文章信息
	 */
	@Override
	public int update(Article article) {
		// TODO Auto-generated method stub
		return  this.jdbcTemplate.update("update article set ar_kinds=?,ar_title=?,ar_img=?,"
				+ "ar_content=?,ar_fileName=?,ar_user=?,ar_filePath=?,ar_time=SYSDATE() where ar_id=?",article.getAr_kinds(),article.getAr_title(),article.getAr_img(),article.getAr_content(),article.getAr_fileName(),article.getAr_user(),article.getAr_filePath(),article.getAr_id());
	}

	public Article load(ResultSet rs) throws SQLException{
		Article article = new Article();
		article.setAr_id(rs.getInt("ar_id"));
		article.setAr_kinds(rs.getInt("ar_kinds"));
		article.setAr_img(rs.getString("ar_img"));
		article.setAr_content(rs.getString("ar_content"));
		article.setAr_title(rs.getString("ar_title"));
		article.setAr_time(rs.getString("ar_time"));
		article.setAr_viewNum(rs.getInt("ar_viewNum"));
		article.setAr_fileName(rs.getString("ar_fileName"));
		article.setAr_filePath(rs.getString("ar_filePath"));
		article.setAr_user(rs.getString("ar_user"));
		return article;
	}
	/**
	 * 查询所有文章
	 */
	@Override
	public List<Article> queryAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from article order by ar_viewNum DESC", 
				new RowMapper<Article>(){
			@Override
			public Article mapRow(ResultSet rs, int index)throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
		}
		);
	}
	/**
	 * 推荐文章
	 */
	@Override
	public List<Article> querySug() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from article ORDER BY ar_viewNum DESC  limit 3", 
				new RowMapper<Article>(){
			@Override
			public Article mapRow(ResultSet rs, int index)throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
		}
		);
	}
	/**
	 * 按照文章种类查询
	 * @param ar_kinds
	 * @return
	 */
	public List<Article> queryByKinds(int ar_kinds){
		String sql="select * from article where ar_kinds=? ORDER BY ar_viewNum DESC";
		Object[] args=new Object[]{ar_kinds};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Article>(){

					@Override
					public Article mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}
	/**
	 * 按照文章ID查询
	 * @param ar_kinds
	 * @return
	 */
	public List<Article> queryById(int ar_id){
		String sql="select * from article where ar_id=?";
		Object[] args=new Object[]{ar_id};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Article>(){

					@Override
					public Article mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}

	@Override
	public List<Article> pageAll(int pageRow,int pageRowMax) {
		// TODO Auto-generated method stub
		String sql="select * from article limit ?,?";
		Object[] args=new Object[]{(pageRow-1)*pageRowMax,pageRowMax};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Article>(){

					@Override
					public Article mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}

	@Override
	public Article searchById(int ar_id) {

		String sql ="select * from article where ar_id=? ";
		Object[] args = new Object[] {ar_id};
		List<Article> article =  this.jdbcTemplate.query(sql,args,new RowMapper<Article>(){
					@Override
					public Article mapRow(ResultSet rs, int index)throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
		if(article.isEmpty())
			return null;
		return (Article)article.get(0);
	}

	/**
	 * 更新文章浏览量
	 */
	public int updateViewNum(int ar_viewNum,int ar_id) {
		// TODO Auto-generated method stub
		String sql="update article set ar_viewNum=? where ar_id=?";
		return  this.jdbcTemplate.update(sql,ar_viewNum,ar_id);
	}
	
	/**
	 * 按照搜索内容查询文章
	 * @param ar_kinds
	 * @return
	 */
	public List<Article> searchBystr(String ar_str){
		String sql="select * from article where ar_title like ? ORDER BY ar_viewNum DESC ";
		String newstr="%"+ar_str+"%";
		Object[] args=new Object[]{newstr};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Article>(){

					@Override
					public Article mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	}
	

	
}
