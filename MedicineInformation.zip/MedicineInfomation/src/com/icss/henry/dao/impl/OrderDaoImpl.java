package com.icss.henry.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.icss.henry.dao.IOrder;
import com.icss.henry.vo.Order;

@Repository
public class OrderDaoImpl implements IOrder{
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	@Override
	public int add(Order order) {
		// TODO Auto-generated method stub
		String sql;
		sql="insert into orderinfo (odinfo_time,odinfo_money,odinfo_state,odinfo_goods_id,odinfo_user_id,odinfo_goods_buynum) values(?,?,0,?,?,?);";
		//sql[1]="update goods set  order_time=?,user_id=?,goods_buynum=? where goods_id=?";
		// jdbcTemplate.update(sql[1],order.getOrder_time(),order.getUser_id(),order.getGoods_buynum(),order.getGoods_id()) ;
		return this.jdbcTemplate.update(sql,order.getOrder_time(),order.getOrder_money(),order.getGoods_id(),order.getUser_id(),order.getGoods_buynum());
	}
	@Override
	public int delete(int order_id) {
		// TODO Auto-generated method stub
		String sql="delete from orderinfo where odinfo_id=?";
		return this.jdbcTemplate.update(sql,order_id);
	}

	@Override
	public int update(Order order) {
		// TODO Auto-generated method stub
		String sql="update orderinfo o set o.odinfo_money=?,o.odinfo_goods_buynum=?,o.odinfo_state=? "
				+ "where  o.odinfo_id=?";
		return this.jdbcTemplate.update(sql,order.getOrder_money(),order.getGoods_buynum(),order.isOrder_state(),order.getOrder_id());
	}
	
	public Order load(ResultSet rs) throws SQLException{
		Order order=new Order();
		float num=rs.getFloat("odinfo_money")/rs.getFloat("goods_price");
		order.setOrder_id(rs.getInt("odinfo_id"));
		order.setOrder_time(rs.getString("odinfo_time"));
		order.setOrder_money(rs.getFloat("odinfo_money"));
		order.setOrder_state(rs.getBoolean("odinfo_state"));
		order.setGoods_name(rs.getString("goods_name"));
		order.setGoods_price(rs.getFloat("goods_price"));
		order.setGoods_buynum(rs.getInt("odinfo_goods_buynum"));
		order.setUser_name(rs.getString("user_name"));
		return order;
	}
	@Override
	public List<Order> queryAll() {
		// TODO Auto-generated method stub
		String sql="select o.odinfo_id,o.odinfo_time,o.odinfo_money,o.odinfo_state,g.goods_name,g.goods_price"+
				",o.odinfo_goods_buynum,u.user_name  from orderinfo o,user u,goods g where o.odinfo_goods_id=g.goods_id and u.user_id=o.odinfo_user_id";
		return this.jdbcTemplate.query(sql,new RowMapper<Order>(){

			@Override
			public Order mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}

		});
	}
	
	@Override
	public List<Order> queryAllByMerchantId(int merchant_id) {
		// TODO Auto-generated method stub
		String sql="select o.odinfo_id,o.odinfo_time,o.odinfo_money,o.odinfo_state,g.goods_name,g.goods_price"+
				",o.odinfo_goods_buynum,u.user_name  from orderinfo o,user u,goods g "+ 
				" where o.odinfo_goods_id=g.goods_id and o.odinfo_user_id=u.user_id "+
				" and g.goods_user_id=? ";
		Object[] args=new Object[]{merchant_id};
		return this.jdbcTemplate.query(sql,args,new RowMapper<Order>(){

			@Override
			public Order mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}

		});
	}


	@Override
	public Order searchById(int order_id) {
		// TODO Auto-generated method stub
		String sql="select * from orderinfo  where  odinfo_id=?";
		Object[] args=new Object[]{order_id};
		List<Order> order= this.jdbcTemplate.query(sql,args,new RowMapper<Order>(){

			@Override
			public Order mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				Order order=new Order();
				order.setOrder_id(rs.getInt("odinfo_id"));
				order.setOrder_time(rs.getString("odinfo_time"));
				order.setOrder_money(rs.getFloat("odinfo_money"));
				order.setOrder_state(rs.getBoolean("odinfo_state"));
				order.setGoods_id(rs.getInt("odinfo_goods_id"));
				order.setUser_id(rs.getInt("odinfo_user_id"));
				order.setGoods_buynum(rs.getInt("odinfo_goods_buynum"));
				return order;
			}

		});
		if(order.isEmpty())
			return null;
		return (Order)order.get(0);
	}

	@Override
	public List<Order> searchBystr(String order_str) {
		// TODO Auto-generated method stub
		String sql="select o.odinfo_id,o.odinfo_time,o.odinfo_money,o.odinfo_state,g.goods_name,g.goods_price"+
				",o.odinfo_goods_buynum,u.user_name  from orderinfo o,user u,goods g where o.odinfo_goods_id=g.goods_id and u.user_id=o.odinfo_user_id  and u.user_name  like ?";;
		String str="%"+order_str+"%";
		Object[] args=new Object[]{str};
		return this.jdbcTemplate.query(sql, args,new RowMapper<Order>(){

			@Override
			public Order mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}		
		});
	}
	@Override
	public int updateSale(int goods_sale,int goods_id){
		String sql="update goods set goods_sale=? where goods_id=?";
		Object[] args=new Object[]{goods_sale,goods_id};
		return this.jdbcTemplate.update(sql,args);
	}

}
