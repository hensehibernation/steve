package com.icss.henry.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.icss.henry.dao.IComment;
import com.icss.henry.vo.Comment;

@Repository
public class CommentDaoImpl implements IComment{
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	@Override
	public int add(Comment comment) {
		// TODO Auto-generated method stub
		String sql="insert into comment (cmt_kinds,cmt_content,cmt_time,cmt_goods_id,cmt_user_id)values(?,?,?,?,?)";
		return this.jdbcTemplate.update(sql,comment.getCmt_kinds(),comment.getCmt_content(),comment.getCmt_time(),
				comment.getGoods_id(),comment.getUser_id());
	}

	@Override
	public int delete(int comment_id) {
		// TODO Auto-generated method stub
		String sql="delete from comment where cmt_id=?";
		return this.jdbcTemplate.update(sql,comment_id);
	}

	@Override
	public int update(Comment comment) {
		// TODO Auto-generated method stub
		String sql="update comment set cmt_kinds=?,cmt_content=?,cmt_time=? where cmt_id=?";
		return this.jdbcTemplate.update(sql,comment.getCmt_kinds(),comment.getCmt_content(),
				comment.getCmt_time(),comment.getCmt_id());
	}

	public Comment load(ResultSet rs) throws SQLException{
		Comment comment=new Comment();
		comment.setCmt_id(rs.getInt("cmt_id"));
		comment.setCmt_kinds(rs.getInt("cmt_kinds"));
		comment.setCmt_content(rs.getString("cmt_content"));
		comment.setCmt_time(rs.getDate("cmt_time"));
		comment.setUser_id(rs.getInt("cmt_user_id"));
		comment.setGoods_id(rs.getInt("cmt_goods_id"));
		return comment;
	}
	@Override
	public List<Comment> queryAll() {
		// TODO Auto-generated method stub
		String sql="select c.cmt_id,c.cmt_kinds,c.cmt_content,c.cmt_time,g.goods_name g_name,u.user_name u_name from comment c,user u,goods g where"
				+ " c.cmt_user_id=u.user_id and g.goods_id=c.cmt_goods_id";
		return this.jdbcTemplate.query(sql, new RowMapper<Comment>(){

			@Override
			public Comment mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				Comment comment=new Comment();
				comment.setCmt_id(rs.getInt("cmt_id"));
				comment.setCmt_kinds(rs.getInt("cmt_kinds"));
				comment.setCmt_content(rs.getString("cmt_content"));
				comment.setCmt_time(rs.getDate("cmt_time"));
				comment.setGoods_name(rs.getString("g_name"));
				comment.setUser_name(rs.getString("u_name"));
				return comment;
			}

		});
	}

	@Override
	public Comment searchById(int comment_id) {
		// TODO Auto-generated method stub
		String sql="select * from comment where cmt_id=?";
		Object[] args=new Object[]{comment_id};
		List<Comment> comment=this.jdbcTemplate.query(sql, args,new RowMapper<Comment>(){

			@Override
			public Comment mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}

		});
		if(comment.isEmpty()){
			return null;
		}
		else{
			return (Comment)comment.get(0);
		}
	}


	@Override
	public List<Comment> queryByKinds(int comment_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Comment> searchBystr(String str) {
		// TODO Auto-generated method stub
		String sql="select c.cmt_id,c.cmt_kinds,c.cmt_content,c.cmt_time,"+
				"g.goods_name g_name,u.user_name u_name from comment c,user u,"+
				"goods g where u.user_id=c.cmt_user_id "+ 
				"and g.goods_id=c.cmt_goods_id and "+
				"u.user_name like ? ";
		String newstr="%"+str+"%";
		Object[] args=new Object[]{newstr};
		return this.jdbcTemplate.query(sql,args,new RowMapper<Comment>(){

			@Override
			public Comment mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				Comment comment=new Comment();
				comment.setCmt_id(rs.getInt("cmt_id"));
				comment.setCmt_kinds(rs.getInt("cmt_kinds"));
				comment.setCmt_content(rs.getString("cmt_content"));
				comment.setCmt_time(rs.getDate("cmt_time"));
				comment.setGoods_name(rs.getString("g_name"));
				comment.setUser_name(rs.getString("u_name"));
				return comment;
			}
			
		});
	}

	@Override
	public List<Comment> queryByGoodsId(int goods_id) {
		// TODO Auto-generated method stub
		String sql="select * from comment where cmt_goods_id=?";
		Object[] args=new Object[]{goods_id};
		return this.jdbcTemplate.query(sql,args, new RowMapper<Comment>(){

			@Override
			public Comment mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}

		});
	}

}
