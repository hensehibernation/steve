package com.icss.henry.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.swing.tree.TreePath;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.icss.henry.dao.IGoods;
import com.icss.henry.vo.Article;
import com.icss.henry.vo.Goods;

import sun.org.mozilla.javascript.internal.ObjArray;

@Repository
public class GoodsDaoImpl implements IGoods{
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	public Goods load(ResultSet rs) throws SQLException{
			Goods goods=new Goods();
			goods.setGoods_id(rs.getInt("goods_id"));
			goods.setGoods_kinds(rs.getInt("goods_kinds"));
			goods.setGoods_name(rs.getString("goods_name"));
			goods.setGoods_price(rs.getFloat("goods_price"));
			goods.setGoods_address(rs.getString("goods_address"));
			goods.setGoods_img(rs.getString("goods_img")); 
			goods.setGoods_msg(rs.getString("goods_msg"));
			goods.setGoods_sale(rs.getInt("goods_sale"));
			goods.setGoods_mhtemail(rs.getString("goods_mhtemail"));
			goods.setGoods_fileName(rs.getString("goods_fileName"));
			goods.setGoods_filePath(rs.getString("goods_filePath"));
			goods.setGoods_shop_name(rs.getString("goods_shop_name"));
			goods.setGoods_user_id(rs.getInt("goods_user_id"));
			return goods;
	}
	/**
	 * 添加商品信息
	 */
	@Override
	public int add(Goods goods) {
		// TODO Auto-generated method stub
		String sql="insert into goods(goods_kinds,goods_name,goods_price,"
				+ "goods_address,goods_img,goods_msg,goods_mhtemail,"
				+ "goods_fileName,goods_filePath,goods_shop_name) values(?,?,?,?,?,?,?,?,?,?)";
		return this.jdbcTemplate.update(sql,goods.getGoods_kinds(),goods.getGoods_name(),
				goods.getGoods_price(),goods.getGoods_address(),goods.getGoods_img(),
				goods.getGoods_msg(),goods.getGoods_mhtemail(),goods.getGoods_fileName(),
				goods.getGoods_filePath(),goods.getGoods_shop_name());
	}
	/**
	 * 删除商品信息
	 */
	@Override
	public int delete(int goods_id) {
		// TODO Auto-generated method stub
		String sql="delete from goods where goods_id=?";
		return this.jdbcTemplate.update(sql,goods_id);
	}

	@Override
	public int update(Goods goods) {
		// TODO Auto-generated method stub
		String sql="update  goods set goods_kinds=?,goods_name=?,goods_price=?,"
				+ "goods_address=?,goods_img=?,goods_msg=?,goods_mhtemail=?,"
				+ "goods_fileName=?,goods_filePath=?,goods_shop_name=? where goods_id=?";
		return this.jdbcTemplate.update(sql,goods.getGoods_kinds(),goods.getGoods_name(),
				goods.getGoods_price(),goods.getGoods_address(),goods.getGoods_img(),
				goods.getGoods_msg(),goods.getGoods_mhtemail(),goods.getGoods_fileName(),
				goods.getGoods_filePath(),goods.getGoods_shop_name(),goods.getGoods_id());
	}

	@Override
	public int updateSale(int goods_sale, int goods_id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Goods> queryAll() {
		// TODO Auto-generated method stub
		String sql="select * from goods";
		return this.jdbcTemplate.query(sql, 
				new RowMapper<Goods>(){

					@Override
					public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
	}
	@Override
	public List<Goods> queryAllByUserId(int goods_user_id) {
		// TODO Auto-generated method stub
		String sql="select * from goods where goods_user_id=?";
		Object[] args=new Object[]{goods_user_id};
		return this.jdbcTemplate.query(sql, args,new RowMapper<Goods>(){

			@Override
			public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
			
		});
	}
	

	@Override
	public List<Goods> querySug() {
		// TODO Auto-generated method stub
		String sql="select * from goods ORDER BY goods_sale DESC  limit 20";
		return this.jdbcTemplate.query(sql, 
				new RowMapper<Goods>(){

					@Override
					public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
		});
	}

	@Override
	public Goods searchById(int goods_id) {
		// TODO Auto-generated method stub
		String sql="select * from goods where goods_id=?";
		Object[] args=new Object[]{goods_id};
		List<Goods> goods=this.jdbcTemplate.query(sql, args,new RowMapper<Goods>(){

			@Override
			public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return load(rs);
			}
			
		});
		if(goods.isEmpty()){
			return null;
		}
		return goods.get(0);
	}

	@Override
	public List<Goods> queryByKinds(int goods_id) {
		// TODO Auto-generated method stub
		String sql="select * from goods where goods_kinds=?";
		Object[] args=new Object[]{goods_id};
		return this.jdbcTemplate.query(sql, args,
				new RowMapper<Goods>(){

					@Override
					public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
			
		});
	}

	@Override
	public List<Goods> pageAll(int pageRow, int pageRowMax) {
		String sql="select * from goods limit ?,?";
		Object[] args=new Object[]{(pageRow-1)*pageRowMax,pageRowMax};
		return this.jdbcTemplate.query(sql,args,
				new RowMapper<Goods>(){

					@Override
					public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}			
		});
	
	}

	@Override
	public List<Goods> searchBystr(String goods_str) {
		// TODO Auto-generated method stub
		String sql="select * from goods where goods_name like ?";
		String str="%"+goods_str+"%";
		Object[] args=new Object[]{str};
		return this.jdbcTemplate.query(sql, args,
				new RowMapper<Goods>(){
					@Override
					public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
			
		});
	}
	/**
	 * 推荐项目
	 */
	public List<Goods> queryByKindsSug(int goods_id) {
		// TODO Auto-generated method stub
		String sql="select * from  goods  where goods_kinds=? ORDER BY goods_sale DESC  limit 4";
		Object[] args=new Object[]{goods_id};
		return this.jdbcTemplate.query(sql, args,
				new RowMapper<Goods>(){

					@Override
					public Goods mapRow(ResultSet rs, int arg1) throws SQLException {
						// TODO Auto-generated method stub
						return load(rs);
					}
			
		});
	}

}
