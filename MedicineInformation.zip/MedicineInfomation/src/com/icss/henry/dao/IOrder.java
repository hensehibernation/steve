package com.icss.henry.dao;

import java.util.List;

import com.icss.henry.vo.Order;

public interface IOrder {
	int add(Order order);
	int delete(int order_id);
	int update(Order order);
	int updateSale(int goods_sale,int goods_id);
	List <Order> queryAll();
	List <Order> queryAllByMerchantId(int merchant_id);
	Order  searchById(int order_id);
	List<Order> searchBystr(String order_str);
}
