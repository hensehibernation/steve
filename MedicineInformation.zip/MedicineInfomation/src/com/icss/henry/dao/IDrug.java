package com.icss.henry.dao;

import java.util.List;

import com.icss.henry.vo.Drug;

public interface IDrug {
	int add(Drug drug);
	int delete(int dr_id);
	int update(Drug drug);
	List<Drug> queryAll();
	List<Drug> querySug();
	Drug  searchById(int dr_id);
	List<Drug> queryById(int dr_id);
	List<Drug> queryByKinds(int dr_id);
	List<Drug> pageAll(int pageRow,int pageRowMax);
	List<Drug> searchBystr(String dr_str);
}
