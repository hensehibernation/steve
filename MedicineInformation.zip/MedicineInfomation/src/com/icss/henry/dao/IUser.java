package com.icss.henry.dao;

import java.util.List;

import com.icss.henry.vo.User;


public interface IUser {
	int add(User user);
	int addMerchant(User user);
	int update(User user);
	int delete(int user_id);
	List<User> search(String ea_title);
	List<User> queryAll();
	User searchByEmail(String user_email,String user_pwd,int user_kinds);
	User searchName(String user_email);
	User searchById(int user_id);
	User queryByEmail(String user_email);
}
