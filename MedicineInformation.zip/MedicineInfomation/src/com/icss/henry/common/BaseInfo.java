package com.icss.henry.common;

public class BaseInfo {
	public final static String USER_SESSION_KEY="user_session_key";
	public final static String ADMIN_SESSION_KEY="admin_session_key";
	public final static String MERCHANT_SESSION_KEY="merchant_session_key";
}
