package com.icss.henry.vo;

public class Order {
	private  int order_id;
	private  String order_time;
	private  float order_money;
	private String goods_name;
	private int goods_num;
	private float goods_price;
	private String goods_img;
	private String goods_filePath;
	private String goods_fileName;
	private int user_id;
	private String user_name;
	private int goods_id;
	private int goods_buynum;
	private boolean order_state;
	
	
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public boolean isOrder_state() {
		return order_state;
	}
	public void setOrder_state(boolean order_state) {
		this.order_state = order_state;
	}
	public int getGoods_buynum() {
		return goods_buynum;
	}
	public void setGoods_buynum(int goods_buynum) {
		this.goods_buynum = goods_buynum;
	}
	public int getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(int goods_id) {
		this.goods_id = goods_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getGoods_img() {
		return goods_img;
	}
	public void setGoods_img(String goods_img) {
		this.goods_img = goods_img;
	}
	public String getGoods_filePath() {
		return goods_filePath;
	}
	public void setGoods_filePath(String goods_filePath) {
		this.goods_filePath = goods_filePath;
	}
	public String getGoods_fileName() {
		return goods_fileName;
	}
	public void setGoods_fileName(String goods_fileName) {
		this.goods_fileName = goods_fileName;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public int getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(int goods_num) {
		this.goods_num = goods_num;
	}
	public float getGoods_price() {
		return goods_price;
	}
	public void setGoods_price(float goods_price) {
		this.goods_price = goods_price;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public String getOrder_time() {
		return order_time;
	}
	public void setOrder_time(String order_time) {
		this.order_time = order_time;
	}
	public float getOrder_money() {
		return order_money;
	}
	public void setOrder_money(float order_money) {
		this.order_money = order_money;
	}
	public Order() {
		super();
	}
	@Override
	public String toString() {
		return "Order [order_id=" + order_id + ", order_time=" + order_time + ", order_money=" + order_money
				+ ", goods_name=" + goods_name + ", goods_num=" + goods_num + ", goods_price=" + goods_price
				+ ", goods_img=" + goods_img + ", goods_filePath=" + goods_filePath + ", goods_fileName="
				+ goods_fileName + ", user_id=" + user_id + ", goods_id=" + goods_id + ", goods_buynum=" + goods_buynum
				+ ", order_state=" + order_state + "]";
	}
  
}
