package com.icss.henry.vo;

import java.util.Date;

public class Comment {
	private int cmt_id;
	private int cmt_kinds;
	private String cmt_content;
	private Date cmt_time;
	private int user_id;
	private int goods_id;
	private String user_name;
	private String goods_name;
	
	
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public int getCmt_id() {
		return cmt_id;
	}
	public void setCmt_id(int cmt_id) {
		this.cmt_id = cmt_id;
	}
	public int getCmt_kinds() {
		return cmt_kinds;
	}
	public void setCmt_kinds(int cmt_kinds) {
		this.cmt_kinds = cmt_kinds;
	}
	public String getCmt_content() {
		return cmt_content;
	}
	public void setCmt_content(String cmt_content) {
		this.cmt_content = cmt_content;
	}
	public Date getCmt_time() {
		return cmt_time;
	}
	public void setCmt_time(Date cmt_time) {
		this.cmt_time = cmt_time;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(int goods_id) {
		this.goods_id = goods_id;
	}
	public Comment() {
		super();
	}
	public Comment(int cmt_kinds, String cmt_content, Date cmt_time, int user_id, int goods_id) {
		super();
		this.cmt_kinds = cmt_kinds;
		this.cmt_content = cmt_content;
		this.cmt_time = cmt_time;
		this.user_id = user_id;
		this.goods_id = goods_id;
	}
	@Override
	public String toString() {
		return "Comment [cmt_id=" + cmt_id + ", cmt_kinds=" + cmt_kinds + ", cmt_content=" + cmt_content + ", cmt_time="
				+ cmt_time + ", user_id=" + user_id + ", goods_id=" + goods_id + ", user_name=" + user_name + "]";
	}
	
	
}
