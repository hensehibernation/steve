package com.icss.henry.vo;

import sunw.io.Serializable;

public class User implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int user_id;
	private String user_name;
	private String user_pwd;
	private int user_kinds;
	private boolean user_sex;
	private String user_tel;
	private String user_address;
	private String user_birthday;
	private String user_email;
	private String user_shop_name;
	
	public String getUser_shop_name() {
		return user_shop_name;
	}
	public void setUser_shop_name(String user_shop_name) {
		this.user_shop_name = user_shop_name;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_pwd() {
		return user_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}
	public int getUser_kinds() {
		return user_kinds;
	}
	public void setUser_kinds(int user_kinds) {
		this.user_kinds = user_kinds;
	}
	public boolean isUser_sex() {
		return user_sex;
	}
	public void setUser_sex(boolean user_sex) {
		this.user_sex = user_sex;
	}
	public String getUser_tel() {
		return user_tel;
	}
	public void setUser_tel(String user_tel) {
		this.user_tel = user_tel;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public String getUser_birthday() {
		return user_birthday;
	}
	public void setUser_birthday(String user_birthday) {
		this.user_birthday = user_birthday;
	}
	
	public User() {
		super();
	}
	@Override
	public String toString() {
		return "User [user_id=" + user_id + ", user_name=" + user_name + ", user_pwd=" + user_pwd + ", user_kinds="
				+ user_kinds + ", user_sex=" + user_sex + ", user_tel=" + user_tel + ", user_address=" + user_address
				+ ", user_birthday=" + user_birthday + ", user_email=" + user_email + "]";
	}
	
	
}
