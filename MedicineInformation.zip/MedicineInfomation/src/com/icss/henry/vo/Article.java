package com.icss.henry.vo;

import sunw.io.Serializable;

public class Article implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int ar_id;
	private int ar_kinds;
	private String ar_title;
	private String ar_img;
	private String ar_content;
	private String ar_time;
	private String ar_fileName;
	private String  ar_user;
	private String ar_filePath;
	
	public String getAr_fileName() {
		return ar_fileName;
	}
	public void setAr_fileName(String ar_fileName) {
		this.ar_fileName = ar_fileName;
	}
	public String getAr_filePath() {
		return ar_filePath;
	}
	public void setAr_filePath(String ar_filePath) {
		this.ar_filePath = ar_filePath;
	}
	private int ar_viewNum;
	public int getAr_id() {
		return ar_id;
	}
	public void setAr_id(int ar_id) {
		this.ar_id = ar_id;
	}
	public int getAr_kinds() {
		return ar_kinds;
	}
	public void setAr_kinds(int ar_kinds) {
		this.ar_kinds = ar_kinds;
	}
	public String getAr_title() {
		return ar_title;
	}
	public void setAr_title(String ar_title) {
		this.ar_title = ar_title;
	}
	public String getAr_img() {
		return ar_img;
	}
	public void setAr_img(String ar_img) {
		this.ar_img = ar_img;
	}
	public String getAr_content() {
		return ar_content;
	}
	public void setAr_content(String ar_content) {
		this.ar_content = ar_content;
	}
	public String getAr_time() {
		return ar_time;
	}
	public void setAr_time(String ar_time) {
		this.ar_time = ar_time;
	}
	public int getAr_viewNum() {
		return ar_viewNum;
	}
	public void setAr_viewNum(int ar_viewNum) {
		this.ar_viewNum = ar_viewNum;
	}
	
	public String getAr_user() {
		return ar_user;
	}
	public void setAr_user(String ar_user) {
		this.ar_user = ar_user;
	}
	
	@Override
	public String toString() {
		return "Article [ar_id=" + ar_id + ", ar_kinds=" + ar_kinds + ", ar_title=" + ar_title + ", ar_img=" + ar_img
				+ ", ar_content=" + ar_content + ", ar_time=" + ar_time + ", ar_fileName=" + ar_fileName + ", ar_user="
				+ ar_user + ", ar_filePath=" + ar_filePath + ", ar_viewNum=" + ar_viewNum + "]";
	}
	
	
	
	
}
