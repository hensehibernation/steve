package com.icss.henry.vo;

public class Drug {
	private int dr_id;
	private String dr_name;
	private int dr_kinds;
	private String dr_msg;
	private String dr_img;
	private String dr_fileName;
	private String dr_filePath;
	public String getDr_img() {
		return dr_img;
	}
	public void setDr_img(String dr_img) {
		this.dr_img = dr_img;
	}
	public int getDr_id() {
		return dr_id;
	}
	public void setDr_id(int dr_id) {
		this.dr_id = dr_id;
	}
	public String getDr_name() {
		return dr_name;
	}
	public void setDr_name(String dr_name) {
		this.dr_name = dr_name;
	}
	public int getDr_kinds() {
		return dr_kinds;
	}
	public void setDr_kinds(int dr_kinds) {
		this.dr_kinds = dr_kinds;
	}
	
	public String getDr_msg() {
		return dr_msg;
	}
	public void setDr_msg(String dr_msg) {
		this.dr_msg = dr_msg;
	}
	
	
	public String getDr_fileName() {
		return dr_fileName;
	}
	public void setDr_fileName(String dr_fileName) {
		this.dr_fileName = dr_fileName;
	}
	public String getDr_filePath() {
		return dr_filePath;
	}
	public void setDr_filePath(String dr_filePath) {
		this.dr_filePath = dr_filePath;
	}
	public Drug() {
		super();
	}
	
	
}
