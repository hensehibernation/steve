package com.icss.henry.vo;

public class Goods {
	private int goods_id;
	private int goods_kinds;
	private String goods_name;
	private float goods_price;
	private String goods_address;
	private String goods_img;
	private int goods_sale;
	private String goods_msg;
	private String goods_mhtemail;
	private String goods_fileName;
	private String goods_filePath;
	private String goods_shop_name;
	private int goods_user_id;
	
	
	public int getGoods_user_id() {
		return goods_user_id;
	}
	public void setGoods_user_id(int goods_user_id) {
		this.goods_user_id = goods_user_id;
	}
	public String getGoods_shop_name() {
		return goods_shop_name;
	}
	public void setGoods_shop_name(String goods_shop_name) {
		this.goods_shop_name = goods_shop_name;
	}
	public int getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(int goods_id) {
		this.goods_id = goods_id;
	}
	public int getGoods_kinds() {
		return goods_kinds;
	}
	public void setGoods_kinds(int goods_kinds) {
		this.goods_kinds = goods_kinds;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public float getGoods_price() {
		return goods_price;
	}
	public void setGoods_price(float goods_price) {
		this.goods_price = goods_price;
	}
	public String getGoods_address() {
		return goods_address;
	}
	public void setGoods_address(String goods_address) {
		this.goods_address = goods_address;
	}
	public String getGoods_img() {
		return goods_img;
	}
	public void setGoods_img(String goods_img) {
		this.goods_img = goods_img;
	}
	public int getGoods_sale() {
		return goods_sale;
	}
	public void setGoods_sale(int goods_sale) {
		this.goods_sale = goods_sale;
	}
	public String getGoods_msg() {
		return goods_msg;
	}
	public void setGoods_msg(String goods_msg) {
		this.goods_msg = goods_msg;
	}
	public String getGoods_fileName() {
		return goods_fileName;
	}
	public void setGoods_fileName(String goods_fileName) {
		this.goods_fileName = goods_fileName;
	}
	public String getGoods_filePath() {
		return goods_filePath;
	}
	public void setGoods_filePath(String goods_filePath) {
		this.goods_filePath = goods_filePath;
	}
	
	public String getGoods_mhtemail() {
		return goods_mhtemail;
	}
	public void setGoods_mhtemail(String goods_mhtemail) {
		this.goods_mhtemail = goods_mhtemail;
	}
	public Goods() {
		super();
	}
	
	
}
