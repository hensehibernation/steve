package com.icss.henry.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.icss.henry.dao.IComment;
import com.icss.henry.dao.IUser;
import com.icss.henry.vo.Comment;
import com.icss.henry.vo.User;

/**
 * 评论管理
 * @author 陈志伟
 *2016年9月24日
 */
@RequestMapping("/comment")
@Controller
public class CommentController {

	@Resource
	IComment ic;
	@Resource
	IUser iu;
	/**
	 * 添加评论
	 * 应用路径：/comment/addComment.shtml;
	 * @param comment
	 * @param user_id
	 * @param goods_id
	 * @return
	 */
	@RequestMapping("/addComment")
	public ModelAndView addComment(
			@RequestAttribute("comment")Comment comment,
			@RequestParam("user_id")int user_id,
			@RequestParam("goods_id")int goods_id){
			comment.setCmt_time(new Date());
			comment.setGoods_id(goods_id);
			comment.setUser_id(user_id);
			String msg="评论成功!";
			ic.add(comment);
			ModelAndView mav=new ModelAndView();
			mav.addObject("comment",comment);
			mav.addObject("msg",msg);
			mav.setViewName("success");
		return mav;
	}
	/**
	 * 更新评论
	 * 应用路径:/comment/updateComment.shtml;
	 * @param comment
	 * @return
	 */
	@RequestMapping("/updateComment")
	public String updateComment(
			@RequestAttribute("comment")Comment comment){
			comment.setCmt_time(new Date());
			System.out.println(comment);
			ic.update(comment);
			//String msg="修改成功~";
			//ModelAndView mav=new ModelAndView();
			//mav.addObject("comment", comment);
			//mav.addObject("msg",msg);
			//mav.setViewName("success");
		return "redirect:getAllComment.shtml";
	}
	/**
	 * 获取所有评论
	 *  应用路径:/comment/getAllComment.shtml;
	 * @return
	 */
	@RequestMapping("/getAllComment")
	public ModelAndView getAllComment(){
		ModelAndView mav=new ModelAndView();
		mav.addObject("comment",ic.queryAll());
		mav.setViewName("bg-comment-list");
		return mav;
	}
	/**
	 * 
	 * @param cmt_id
	 * @return
	 */
	@RequestMapping("/getCommentById")
	public ModelAndView  getCommentById(
			@RequestParam("cmt_id")int cmt_id){
		ModelAndView mav=new ModelAndView();
		mav.addObject("comment",ic.searchById(cmt_id));
		mav.setViewName("update-comment");
		return mav;
	}
	/**
	 * 搜索评论
	 * 应用路径:/comment/searchByStr.shtml;
	 * @param str
	 * @return
	 */
	@RequestMapping("/searchByStr")
	public ModelAndView searchByStr(
			@RequestParam("str")String str){
		ModelAndView mav=new ModelAndView();
		mav.addObject("str",str);
		System.out.println(str);
		mav.addObject("comment",ic.searchBystr(str));
		mav.setViewName("bg-comment-list");	
		return mav;
	}
	/**
	 * 删除评论
	 * 应用路径:/comment/deleteComment.shtml;
	 * @param cmt_id
	 * @return
	 */
	@RequestMapping("/deleteComment")
	public String deleteComment(
			@RequestParam("cmt_id")int cmt_id){
		ic.delete(cmt_id);
		return "redirect:getAllComment.shtml";
	}
	/**
	 * 获取所有评论的json
	 * 应用路径:/comment/getCommentListJson.shtml;
	 * @param commentId
	 * @param goods_id
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getCommentListJson")
	public List getCommentListJson(Integer commentId,
			@RequestParam("goods_id")int goods_id){
		List<Comment> list=new ArrayList<>();
		for(Comment comment: ic.queryByGoodsId(goods_id)){
			User user=iu.searchById(comment.getUser_id());
			comment.setUser_name(user.getUser_name());
			list.add(comment);
		}
		return list;
	}
}
