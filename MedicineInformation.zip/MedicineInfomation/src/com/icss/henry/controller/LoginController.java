package com.icss.henry.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.jws.WebParam.Mode;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.icss.henry.common.BaseInfo;
import com.icss.henry.dao.IArticle;
import com.icss.henry.dao.IDrug;
import com.icss.henry.dao.IGoods;
import com.icss.henry.dao.IUser;
import com.icss.henry.vo.Article;
import com.icss.henry.vo.Drug;
import com.icss.henry.vo.Goods;
import com.icss.henry.vo.User;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
/**
 * 用户管理
 * @author 陈志伟
 *2016年9月24日
 */
@RequestMapping("/user")
@Controller
public class LoginController {
	@Resource
	IUser iuser;
	@Resource
	IGoods ig;
	@Resource
	IArticle ia;
	@Resource
	IDrug id;

	/**
	 * 管理员登陆
	 * @param user
	 * @param session
	 * @return
	 */
	@RequestMapping("/toLoginAdmin")
	public ModelAndView toLoginAdmin(
			@ModelAttribute("user")User user,HttpSession session
			){
		//匹配数据库信息
		User userList =(User)iuser.searchByEmail(user.getUser_email(),user.getUser_pwd(),3);
		if(userList!=null){
			ModelAndView mav=new ModelAndView();
			mav.addObject("user",userList);
			session.setAttribute(BaseInfo.ADMIN_SESSION_KEY, userList);
			session.setMaxInactiveInterval(300*60);
			mav.setViewName("background-index");
			return mav;
		}else{
			ModelAndView mav=new ModelAndView();
			String error="登录名或密码错误";
			mav.addObject("error",error);
			mav.setViewName("admin-login");
			return mav;
		}		

	}

	/**
	 * 输出首页信息
	 * 应用路径:/user/index.shtml
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/index")
	public ModelAndView index(
	
		HttpServletRequest request) throws IOException{
		HttpSession session=request.getSession();
		ModelAndView mav=new ModelAndView();
		String path=request.getSession().getServletContext().getRealPath("/upload");
		//输出推荐商品
		for (Goods goods : ig.queryAll()) {		
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
		}
		//输出推荐文章
		for (Article article : ia.querySug()) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			BASE64Decoder decoder=new BASE64Decoder();
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
		}
		//输出推荐文章
		for (Drug drug : id.querySug()) {		
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			BASE64Decoder decoder=new BASE64Decoder();
			byte[] bytes1 = decoder.decodeBuffer(drug.getDr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
		}
		//输出信息到首页
			mav.addObject("goods_kinds1",ig.queryByKindsSug(1));
			mav.addObject("goods_kinds2",ig.queryByKindsSug(2));
			mav.addObject("goods_kinds3",ig.queryByKindsSug(3));
			mav.addObject("goods_kinds4",ig.queryByKindsSug(4));
			mav.addObject("goods_kinds5",ig.queryByKindsSug(5));
			mav.addObject("article",ia.querySug());
			mav.addObject("drug",id.querySug());
			mav.setViewName("index");
			return mav;
	}
	/**
	 * 登陆
	 * 应用路径:user/toLogin.shtml
	 * @param user
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/toLogin")
	public ModelAndView toLogin(
			@ModelAttribute("user")User user
			,HttpServletRequest request) throws IOException{
		HttpSession session=request.getSession();
		ModelAndView mav=new ModelAndView();
		User userM=(User)session.getAttribute(BaseInfo.USER_SESSION_KEY);
		//匹配数据库
		User userList =(User)iuser.searchByEmail(user.getUser_email(),user.getUser_pwd(),1);
		String path=request.getSession().getServletContext().getRealPath("/upload");
		for (Goods goods : ig.queryAll()) {		
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
		}
		for (Article article : ia.querySug()) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			BASE64Decoder decoder=new BASE64Decoder();
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
		}
		for (Drug drug : id.querySug()) {		
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			BASE64Decoder decoder=new BASE64Decoder();
			byte[] bytes1 = decoder.decodeBuffer(drug.getDr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
		}
		if(userM!=null){
			User userA=iuser.searchByEmail(userM.getUser_email(), userM.getUser_pwd(), 1);
			mav.addObject("user",userA);
			mav.addObject("goods_kinds1",ig.queryByKindsSug(1));
			mav.addObject("goods_kinds2",ig.queryByKindsSug(2));
			mav.addObject("goods_kinds3",ig.queryByKindsSug(3));
			mav.addObject("goods_kinds4",ig.queryByKindsSug(4));
			mav.addObject("goods_kinds5",ig.queryByKindsSug(5));
			mav.addObject("article",ia.querySug());
			mav.addObject("drug",id.querySug());
			mav.setViewName("index");
			return mav;
		}
		else if(userList!=null){			
			session.setAttribute(BaseInfo.USER_SESSION_KEY, user);
			session.setMaxInactiveInterval(300*60);
			mav.addObject("user",userList);
			mav.addObject("goods_kinds1",ig.queryByKindsSug(1));
			mav.addObject("goods_kinds2",ig.queryByKindsSug(2));
			mav.addObject("goods_kinds3",ig.queryByKindsSug(3));
			mav.addObject("goods_kinds4",ig.queryByKindsSug(4));
			mav.addObject("goods_kinds5",ig.queryByKindsSug(5));
			mav.addObject("article",ia.querySug());
			mav.addObject("drug",id.querySug());
			mav.setViewName("index");
			return mav;
		}else{
			String error="登录名或密码错误";
			mav.addObject("error",error);
			mav.setViewName("user-login");
			return mav;
		}	
	}
	/**
	 * 商户登陆
	 * 应用路径/user/merchantToLogin.shtml
	 * @param user
	 * @param request
	 * @return
	 */
	@RequestMapping("/merchantToLogin")
	public ModelAndView  merchantToLogin(
			@ModelAttribute("user")User user
			,HttpServletRequest request){
		HttpSession session=request.getSession();
		ModelAndView mav=new ModelAndView();
		User userM=(User)session.getAttribute(BaseInfo.MERCHANT_SESSION_KEY);
		User userList =(User)iuser.searchByEmail(user.getUser_email(),user.getUser_pwd(),2);
		if(userM!=null){
			User userA=iuser.searchByEmail(userM.getUser_email(), userM.getUser_pwd(), 2);
			mav.addObject("user",userA);
			mav.setViewName("merchant-bg-index");
			return mav;
		}
		else if(userList!=null){			
			session.setAttribute(BaseInfo.MERCHANT_SESSION_KEY, user);
			session.setMaxInactiveInterval(300*60);
			mav.addObject("user",userList);
			mav.setViewName("merchant-bg-index");
			return mav;
		}else{
			String error="登录名或密码错误";
			mav.addObject("error",error);
			mav.setViewName("merchant-login");
			return mav;
		}	
	}

	/**
	 * 商户注册
	 * 应用路径:user/toMerchantReg.shtml
	 * @param user
	 * @param session
	 * @return
	 */
	@RequestMapping("/toMerchantReg")
	public ModelAndView toMerchantReg(
			@ModelAttribute("user")User user
			,HttpSession session){
		iuser.addMerchant(user);			
		ModelAndView mav=new ModelAndView();
		mav.setViewName("merchant-login");
		return mav;
	}
	/**
	 * 普通用户注册
	 * 应用路径:/user/toReg.shtml
	 * @param user
	 * @param session
	 * @return
	 */
	@RequestMapping("/toReg")
	public ModelAndView toReg(
			@ModelAttribute("user")User user
			,HttpSession session){
		iuser.add(user);			
		ModelAndView mav=new ModelAndView();
		mav.setViewName("user-login");
		return mav;
	}
	/**
	 * 验证邮箱的json
	 * /user/getUserEmailJson.shtml
	 * @param user_email
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/getUserEmailJson")
	public User getUserEmailJson(
			@RequestParam("user_email")String user_email){
		User user=iuser.queryByEmail(user_email);
		return user;
	}
	//将图片转成base64格式
	public String base64Encoder(MultipartFile file,String suffixName) throws IOException{
		BASE64Encoder encoder=new BASE64Encoder();

		BufferedImage bi;
		bi = ImageIO.read(file.getInputStream());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();   
		ImageIO.write(bi, suffixName, baos);   
		byte[] bytes = baos.toByteArray();   
		String base64=encoder.encodeBuffer(bytes).trim();
		return base64;
	}
	/**
	 * 按id搜索用户信息
	 * 用用路径：/user/searchUserById.shtml
	 * @param user_id
	 * @return
	 */
	@RequestMapping("/searchUserById")
	public ModelAndView searchUserById(
			@RequestParam("user_id")int user_id){
		ModelAndView mav=new ModelAndView();
		mav.addObject("user",iuser.searchById(user_id));
		mav.setViewName("update-user");
		return mav;
	}
	/**
	 * 更新用户信息
	 * /user/updateUser.shtml
	 * @param user
	 * @return
	 */
	@RequestMapping("/updateUser")
	public String updateUser(
			@ModelAttribute("user")User user){
		iuser.update(user);
		return "redirect:getAllUser.shtml";
	}
	/**
	 * 获取所有用户
	 * 应用路径:/user/getAllUser.shtml
	 * @return
	 */
	@RequestMapping("/getAllUser")
	public ModelAndView getAllUser(){
		ModelAndView mav=new ModelAndView();
		mav.addObject("user",iuser.queryAll());
		mav.setViewName("bg-user-list");
		return mav;
	}
	/**
	 * 搜索输入的内容
	 * @param str
	 * @return
	 */
	@RequestMapping("/searchByStr")
	public ModelAndView searchByStr(
			@RequestParam("str")String str){
		ModelAndView mav=new ModelAndView();
		mav.addObject("user",iuser.search(str));
		mav.addObject("str",str);
		mav.setViewName("bg-user-list");
		return mav;
	}
	//将base64转成图片
	public void  base64Decoder(Goods goods,String suffixName,File serverFile) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		byte[] bytes1 = decoder.decodeBuffer(goods.getGoods_img());   
		ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
		BufferedImage bi1 =ImageIO.read(bais);   
		ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
	}

	//获得文件后缀名
	public String getSuffix(MultipartFile file,HttpServletRequest request){
		String originalName=file.getOriginalFilename();
		//拿到上传文件的后缀
		int index=originalName.lastIndexOf(".");
		//从0开始
		String suffixName=originalName.substring(index+1);
		//存在服务器上文件的名字，自己的算法生成	
		return suffixName;
	}
	//获得文件名字
	public String getFileName(MultipartFile file,HttpServletRequest request){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String prefixName=sdf.format(new Date());
		//服务器上存文件的后缀=上传文件的后缀
		//服务器上存储文件的完整 的名字
		String fileName=prefixName+"."+getSuffix(file,request);
		return fileName;
	}
	//获得文件路径
	public String getFilePath(MultipartFile file,HttpServletRequest request){
		//找到上传文件的目录的路径
		String path=request.getSession().getServletContext().getRealPath("/upload");
		//文件的完整路径
		String filePath=path+"/"+getFileName(file,request);
		return filePath;
	}
	//创建文件
	public File getServerFile(MultipartFile file,HttpServletRequest request){
		//把上传的文件存储到服务器
		File serverFile =new File(getFilePath(file,request));
		return serverFile;
	}
}
