package com.icss.henry.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.icss.henry.common.BaseInfo;
import com.icss.henry.dao.IDrug;
import com.icss.henry.dao.IUser;
import com.icss.henry.vo.Article;
import com.icss.henry.vo.Drug;
import com.icss.henry.vo.User;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
/**
 * 药品管理
 * @author 陈志伟
 *2016年9月24日
 */
@RequestMapping("/drug")
@Controller
public class DrugController {

	@Resource
	private IDrug id;
	@Resource
	private IUser iu;
	//将图片转成base64格式
	public String base64Encoder(MultipartFile file,String suffixName) throws IOException{
		BASE64Encoder encoder=new BASE64Encoder();

		BufferedImage bi;
		bi = ImageIO.read(file.getInputStream());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();   
		ImageIO.write(bi, suffixName, baos);   
		byte[] bytes = baos.toByteArray();   
		String base64=encoder.encodeBuffer(bytes).trim();
		return base64;
	}
	//将base64转成图片
	public void  base64Decoder(Drug drug,String suffixName,File serverFile) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		byte[] bytes1 = decoder.decodeBuffer(drug.getDr_img());   
		ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
		BufferedImage bi1 =ImageIO.read(bais);   
		ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
	}
	//获得文件后缀名
	public String getSuffix(MultipartFile file,HttpServletRequest request){
		String originalName=file.getOriginalFilename();
		//拿到上传文件的后缀
		int index=originalName.lastIndexOf(".");
		//从0开始
		String suffixName=originalName.substring(index+1);
		//存在服务器上文件的名字，自己的算法生成	
		return suffixName;
	}
	//获得文件名字
	public String getFileName(MultipartFile file,HttpServletRequest request){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String prefixName=sdf.format(new Date());
		//服务器上存文件的后缀=上传文件的后缀
		//服务器上存储文件的完整 的名字
		String fileName=prefixName+"."+getSuffix(file,request);
		return fileName;
	}
	//获得文件路径
	public String getFilePath(MultipartFile file,HttpServletRequest request){
		//找到上传文件的目录的路径
		String path=request.getSession().getServletContext().getRealPath("/upload");
		//文件的完整路径
		String filePath=path+"/"+getFileName(file,request);
		return filePath;
	}
	//创建文件
	public File getServerFile(MultipartFile file,HttpServletRequest request){
		//把上传的文件存储到服务器
		File serverFile =new File(getFilePath(file,request));
		return serverFile;
	}


	/**
	 * 应用路径/drug/addDrug.shtml
	 * @param request
	 * @param drug
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/addDrug")
	public String addDrug(
			HttpServletRequest request
			,@ModelAttribute("drug")Drug drug,HttpSession session) throws IOException{
		MultipartHttpServletRequest mrequest=(MultipartHttpServletRequest) request;
		MultipartFile file=mrequest.getFile("file");
		InputStream inputStream=file.getInputStream();
		if(!getServerFile(file, mrequest).exists()){
			getServerFile(file, mrequest).createNewFile();
		}

		drug.setDr_img(base64Encoder(file, getSuffix(file, request)));

		drug.setDr_filePath(getFilePath(file,request));
		drug.setDr_fileName(getFileName(file,request));
		id.add(drug);
		ModelAndView mav=new ModelAndView();
		mav.addObject("drug",drug);
		mav.setViewName("bg-drug-list");
		return "redirect:getAllDrug.shtml";
	}
	/**
	 * 应用路径/drug/getAllDrug.shtml
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/getAllDrug")
	public ModelAndView getAllDrug(HttpServletRequest request) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");
		for (Drug drug : id.queryAll()) {		
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(drug, suffixName, serverFile);
			total++;
		}
		mav.addObject("arlist",id.queryAll());
		mav.addObject("total",total);
		mav.setViewName("bg-drug-list");
		return mav;
	}
	
	/**
	 * 输出搜索内容到后台页面
	 * 应用路径:/drug/searchBystr.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/searchBystr")
	public ModelAndView searchBystr(HttpServletRequest request
			,@ModelAttribute("drug")Drug drugM) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Drug drug : id.searchBystr(drugM.getDr_name())) {
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(drug, suffixName, serverFile);
			total++;
		}
//		System.out.println(total);
		mav.addObject("arlist",id.searchBystr(drugM.getDr_name()));
		mav.addObject("total",total);
		mav.addObject("str",drugM.getDr_name());
		mav.setViewName("bg-drug-list");
		return mav;
	}
	
	/**
	 * 输出文章信息到前台界面
	 * 应用路径:/drug/getAllDrugToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping("/getAllDrugToIndex")
	public ModelAndView getAllDrugToIndex(HttpServletRequest request) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Drug drug : id.queryAll()) {
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(drug, suffixName, serverFile);
			total++;
		}
		HttpSession session=request.getSession();
		session.setMaxInactiveInterval(5000*60);
		User user=(User)session.getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		mav.addObject("list",id.queryAll());
		mav.addObject("total",total);
		mav.setViewName("drug-list");
		return mav;
	}
	
	/**
	 * 按种类输出中药信息到前台界面
	 * 应用路径:/drug/getDrugByKindsToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/getDrugByKindsToIndex",method=RequestMethod.GET)
	public ModelAndView getDrugByKindsToIndex(HttpServletRequest request
			,@RequestParam(value="dr_kinds",required=false)int dr_kinds) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Drug drug : id.queryByKinds(dr_kinds)) {
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(drug, suffixName, serverFile);
			total++;
		}
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		mav.addObject("list",id.queryByKinds(dr_kinds));
		mav.addObject("total",total);
		mav.setViewName("drug-list");
		return mav;
	}
	
	/**
	 * 输出搜索内容到后台页面
	 * 应用路径:/drug/searchBystrToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/searchBystrToIndex")
	public ModelAndView searchBystrToIndex(HttpServletRequest request
			,@ModelAttribute("drug")Drug drugM) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Drug drug : id.searchBystr(drugM.getDr_name())) {
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(drug, suffixName, serverFile);
			total++;
		}
		mav.addObject("list",id.searchBystr(drugM.getDr_name()));
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		mav.addObject("total",total);
		mav.addObject("str",drugM.getDr_name());
		mav.setViewName("drug-list");
		return mav;
	}
	/**
	 * 分页
	 * 应用路径:/drug/page.shtml
	 * @param request
	 * @param page
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value="/page",method=RequestMethod.GET)
	public ModelAndView page(HttpServletRequest request
			,@RequestParam(value="page",required=false)int page) throws IOException{
		ModelAndView mav=new ModelAndView();
		int pageRowMax=2;
		int total=0;
		for (Drug drug : id.queryAll()) {
			total++;
		}
		mav.addObject("arlist",id.pageAll(page,pageRowMax));
		mav.addObject("total",total);
		mav.setViewName("bg-drug-list");
		
		return mav;
	}
	/**
	 * 更新药品信息
	 * 应用路径：/drug/updateDrug.shtml
	 * @param request
	 * @param article
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/updateDrug")
	public String updateArticle(HttpServletRequest request
			,@ModelAttribute("drug")Drug drug,HttpSession session		
			) throws IOException{
		MultipartHttpServletRequest mrequest=(MultipartHttpServletRequest) request;
		MultipartFile file=mrequest.getFile("file");
		InputStream inputStream=file.getInputStream();
		if(!getServerFile(file, mrequest).exists()){
			getServerFile(file, mrequest).createNewFile();
		}

		drug.setDr_img(base64Encoder(file, getSuffix(file, request)));

		drug.setDr_filePath(getFilePath(file,request));
		drug.setDr_fileName(getFileName(file,request));
//		System.out.println(article);
		id.update(drug);
		return "redirect:getAllDrug.shtml";
	}
	
	/**
	 * 按id查询药品
	 * 应用路径:/drug/getDrugById.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/getDrugById",method=RequestMethod.GET)
	public ModelAndView getDrugById(HttpServletRequest request
			,@RequestParam(value="dr_id",required=false)int dr_id) throws IOException{
		ModelAndView mav=new ModelAndView();	
//		System.out.println(total);
		for (Drug drug : id.queryById(dr_id)) {
			mav.addObject("drByIdList",drug);
		}	
		mav.setViewName("update-drug");
		return mav;
	}
	/**
	 * 删除药品
	 * 应用路径:/article/deleteDrug.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/deleteDrug",method=RequestMethod.GET)
	public String deleteDrug(
			@RequestParam(value="dr_id",required=false)int dr_id) throws IOException{	
		id.delete(dr_id);	
		return "redirect:getAllDrug.shtml";
	}
	/**
	 * 获取药品详情
	 * 应用路径：/drug/getDrugDetail.shtml
	 * @param dr_id
	 * @return
	 */
	@RequestMapping(value="/getDrugDetail",method=RequestMethod.GET)
	public ModelAndView getDrugDetail(
			@RequestParam(value="dr_id",required=false)int dr_id
			){
		ModelAndView mav=new ModelAndView();
		Drug drug=id.searchById(dr_id);
		String conprifix="<pre style='font-size:24px;background-color:white;border:0px;margin:0;padding:0;'>";
		String consuffix="</pre>";
		String content=conprifix+drug.getDr_msg()+consuffix; 
		drug.setDr_msg(content);
		mav.addObject("list",drug);
		mav.setViewName("drug-detail");		
		return mav;
	}
}
