package com.icss.henry.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.icss.henry.common.BaseInfo;
import com.icss.henry.dao.IArticle;
import com.icss.henry.dao.IUser;
import com.icss.henry.vo.Article;
import com.icss.henry.vo.User;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
/**
 * 文章管理
 * @author 陈志伟
 *2016年9月24日
 */
@RequestMapping("/article")
@Controller
public class ArticleController {
	@Resource
	IArticle ia;
	@Resource
	IUser iu;
	private int ar_viewNum=0;
	/**
	 * 添加文章
	 * 应用路径：/article/addArticle.shtml
	 * @param request
	 * @param article
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/addArticle")
	public String addArticle(HttpServletRequest request
			,@ModelAttribute("article")Article article,HttpSession session) throws IOException{
		MultipartHttpServletRequest mrequest=(MultipartHttpServletRequest) request;
		MultipartFile file=mrequest.getFile("file");
		//拿到上传的文件原来的完整的名字123.doc
		String originalName=file.getOriginalFilename();
		//拿到上传文件的后缀
		int index=originalName.lastIndexOf(".");
		//从0开始
		String suffixName=originalName.substring(index+1);
		//存在服务器上文件的名字，自己的算法生成
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String prefixName=sdf.format(new Date());
		//服务器上存文件的后缀=上传文件的后缀
		//服务器上存储文件的完整 的名字
		String fileName=prefixName+"."+suffixName;
		//把上传的文件存储到服务器
		//找到上传文件的目录的路径
		String path=request.getSession().getServletContext().getRealPath("/upload");
		//文件的完整路径
		String filePath=path+"/"+fileName;
		File serverFile =new File(filePath);
		//输出流,拿到上传文件的内容
		InputStream inputStream=file.getInputStream();
		if(!serverFile.exists()){
			serverFile.createNewFile();
		}
		BASE64Encoder encoder=new BASE64Encoder();
		
		BufferedImage bi;
		bi = ImageIO.read(file.getInputStream());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();   
		ImageIO.write(bi, suffixName, baos);   
		byte[] bytes = baos.toByteArray();   
		article.setAr_img(encoder.encodeBuffer(bytes).trim());
		
		article.setAr_filePath(filePath);
		article.setAr_fileName(fileName);
		User user2=((User)request.getSession().getAttribute(BaseInfo.ADMIN_SESSION_KEY));
		article.setAr_user(user2.getUser_name());
		ia.add(article);
		ModelAndView mav=new ModelAndView();
		mav.addObject("article",article);
		mav.setViewName("bg-eassy-list");
		return "redirect:getAllArticle.shtml";
	}
	
	/**
	 * 输出文章信息到后台界面
	 * 应用路径:/article/getAllArticle.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping("/getAllArticle")
	public ModelAndView getAllArticle(HttpServletRequest request) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Article article : ia.queryAll()) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
			total++;
		}
//		System.out.println(total);
		mav.addObject("arlist",ia.queryAll());
		mav.addObject("total",total);
		mav.setViewName("bg-eassy-list");
		return mav;
	}
	
	
	/**
	 * 输出搜索内容到后台页面
	 * 应用路径:/article/searchBystr.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/searchBystr")
	public ModelAndView searchBystr(HttpServletRequest request
			,@ModelAttribute("article")Article articleM) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Article article : ia.searchBystr(articleM.getAr_title())) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
			total++;
		}
//		System.out.println(total);
		mav.addObject("arlist",ia.searchBystr(articleM.getAr_title()));
		mav.addObject("total",total);
		mav.setViewName("bg-eassy-list");
		mav.addObject("str",articleM.getAr_title());
		return mav;
	}
	
	/**
	 * 输出文章信息到前台界面
	 * 应用路径:/article/getAllArticleToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping("/getAllArticleToIndex")
	public ModelAndView getAllArticleToIndex(HttpServletRequest request) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Article article : ia.queryAll()) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
			total++;
		}
		HttpSession session=request.getSession();
		session.setMaxInactiveInterval(5000*60);
		User user=(User)session.getAttribute(BaseInfo.USER_SESSION_KEY);

		mav.addObject("list",ia.queryAll());
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		mav.addObject("total",total);
		mav.setViewName("eassy-list");
		return mav;
	}
	
	/**
	 * 按种类输出文章信息到前台界面
	 * 应用路径:/article/getArticleByKindsToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/getArticleByKindsToIndex",method=RequestMethod.GET)
	public ModelAndView getArticleByKindsToIndex(HttpServletRequest request
			,@RequestParam(value="ar_kinds",required=false)int ar_kinds) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Article article : ia.queryByKinds(ar_kinds)) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
			total++;
		}
//		System.out.println(total);
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		mav.addObject("list",ia.queryByKinds(ar_kinds));
		mav.addObject("total",total);
		mav.setViewName("eassy-list");
		return mav;
	}
	
	/**
	 * 输出搜索内容到后台页面
	 * 应用路径:/article/searchBystrToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/searchBystrToIndex")
	public ModelAndView searchBystrToIndex(HttpServletRequest request
			,@ModelAttribute("article")Article articleM) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Article article : ia.searchBystr(articleM.getAr_title())) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
			total++;
		}
		mav.addObject("list",ia.searchBystr(articleM.getAr_title()));
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		mav.addObject("total",total);
		mav.addObject("str", articleM.getAr_title());
		mav.setViewName("eassy-list");
		return mav;
	}
	
	/**
	 * 分页
	 * 应用路径:/article/page.shtml
	 * @param request
	 * @param page
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value="/page",method=RequestMethod.GET)
	public ModelAndView page(HttpServletRequest request
			,@RequestParam(value="page",required=false)int page) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		ModelAndView mav=new ModelAndView();
		int pageRowMax=2;
		int total=0;
		for (Article article : ia.queryAll()) {
			total++;
		}
		mav.addObject("arlist",ia.pageAll(page,pageRowMax));
		mav.addObject("total",total);
		mav.setViewName("bg-eassy-list");
		
		return mav;
	}
	/**
	 * 分页
	 * 应用路径：/article/pageListJson.shtml
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@ResponseBody
	@RequestMapping(value="/pageListJson")
	public List pageListJson(HttpServletRequest request
			) throws IOException{
		int pageRowMax=2;
		int total=0;
		List<Article> list=new ArrayList<>();
		for (Article article : ia.queryAll()) {
			total++;
		}
		for(Article article : ia.pageAll(1, pageRowMax)){
			list.add(article);
		}
//		mav.addObject("arlist",ia.pageAll(page,pageRowMax));
//		mav.addObject("total",total);
//		mav.setViewName("bg-eassy-list");
		
		return list;
	}
	/**
	 * 应用路径：/article/updateArticle.shtml
	 * @param request
	 * @param article
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/updateArticle")
	public String updateArticle(HttpServletRequest request
			,@ModelAttribute("article")Article article,HttpSession session		
			) throws IOException{
		MultipartHttpServletRequest mrequest=(MultipartHttpServletRequest) request;
		MultipartFile file=mrequest.getFile("file");
		
		//拿到上传的文件原来的完整的名字123.doc
		String originalName=file.getOriginalFilename();
		//拿到上传文件的后缀
		int index=originalName.lastIndexOf(".");
		//从0开始
		String suffixName=originalName.substring(index+1);
		//存在服务器上文件的名字，自己的算法生成
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String prefixName=sdf.format(new Date());
		//服务器上存文件的后缀=上传文件的后缀
		//服务器上存储文件的完整 的名字
		String fileName=prefixName+"."+suffixName;
		//把上传的文件存储到服务器
		//找到上传文件的目录的路径
		String path=request.getSession().getServletContext().getRealPath("/upload");
		//文件的完整路径
		String filePath=path+"/"+fileName;
		File serverFile =new File(filePath);
		//输出流,拿到上传文件的内容
		InputStream inputStream=file.getInputStream();
		if(!serverFile.exists()){
			serverFile.createNewFile();
		}
		BASE64Encoder encoder=new BASE64Encoder();
		
		BufferedImage bi;
		bi = ImageIO.read(file.getInputStream());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();   
		ImageIO.write(bi, suffixName, baos);   
		byte[] bytes = baos.toByteArray();   
		article.setAr_img(encoder.encodeBuffer(bytes).trim());
		
		article.setAr_filePath(filePath);
		article.setAr_fileName(fileName);
		User user2=((User)request.getSession().getAttribute(BaseInfo.ADMIN_SESSION_KEY));
		article.setAr_user(user2.getUser_name());
//		System.out.println(article);
		ia.update(article);
		return "redirect:getAllArticle.shtml";
	}
	/**
	 * 按id查询文章
	 * 应用路径:/article/getArticleById.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/getArticleById",method=RequestMethod.GET)
	public ModelAndView getArticleById(HttpServletRequest request
			,@RequestParam(value="ar_id",required=false)int ar_id) throws IOException{
		ModelAndView mav=new ModelAndView();	
//		System.out.println(total);
		for (Article article : ia.queryById(ar_id)) {
			mav.addObject("arByIdList",article);
		}	
		mav.setViewName("update-article");
		return mav;
	}
	
	/**
	 * 删除文章
	 * 应用路径:/article/deleteArticle.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/deleteArticle",method=RequestMethod.GET)
	public String deleteArticle(
			@RequestParam(value="ar_id",required=false)int ar_id) throws IOException{	
		ia.delete(ar_id);	
		return "redirect:getAllArticle.shtml";
	}
	/**
	 * 获取文章详情
	 * 应用路径：/article/getArticleDetail.shtml
	 * @param ar_id
	 * @return
	 */
	@RequestMapping(value="/getArticleDetail",method=RequestMethod.GET)
	public ModelAndView getArticleDetail(
			@RequestParam(value="ar_id",required=false)int ar_id
			){
		ModelAndView mav=new ModelAndView();
		Article articleA=ia.searchById(ar_id);
		ar_viewNum=articleA.getAr_viewNum()+1;
		ia.updateViewNum(ar_viewNum, ar_id);
		Article article=ia.searchById(ar_id);
		String conprifix="<pre style='font-size:24px;background-color:white;border:0px;margin:0;padding:0;'>";
		String consuffix="</pre>";
		String content=conprifix+article.getAr_content()+consuffix; 
		article.setAr_content(content);
		mav.addObject("list",article);
		mav.setViewName("article-detail");		
		return mav;
	}
	
}
