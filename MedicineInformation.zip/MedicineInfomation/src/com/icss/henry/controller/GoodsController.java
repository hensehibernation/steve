package com.icss.henry.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.icss.henry.common.BaseInfo;
import com.icss.henry.dao.IArticle;
import com.icss.henry.dao.IDrug;
import com.icss.henry.dao.IGoods;
import com.icss.henry.dao.IUser;
import com.icss.henry.vo.Article;
import com.icss.henry.vo.Drug;
import com.icss.henry.vo.Goods;
import com.icss.henry.vo.User;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
/**
 * 养生项目管理
 * @author 陈志伟
 *2016年9月24日
 */
@Controller
@RequestMapping("/goods")
public class GoodsController {
	@Resource 
	private IGoods ig;
	@Resource
	private IArticle ia;
	@Resource
	private IDrug id;
	@Resource
	private IUser iu;
	//将图片转成base64格式
	public String base64Encoder(MultipartFile file,String suffixName) throws IOException{
		BASE64Encoder encoder=new BASE64Encoder();

		BufferedImage bi;
		bi = ImageIO.read(file.getInputStream());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();   
		ImageIO.write(bi, suffixName, baos);   
		byte[] bytes = baos.toByteArray();   
		String base64=encoder.encodeBuffer(bytes).trim();
		return base64;
	}
	//将base64转成图片
	public void  base64Decoder(Goods goods,String suffixName,File serverFile) throws IOException{
		BASE64Decoder decoder=new BASE64Decoder();
		byte[] bytes1 = decoder.decodeBuffer(goods.getGoods_img());   
		ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
		BufferedImage bi1 =ImageIO.read(bais);   
		ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
	}

	//获得文件后缀名
	public String getSuffix(MultipartFile file,HttpServletRequest request){
		String originalName=file.getOriginalFilename();
		//拿到上传文件的后缀
		int index=originalName.lastIndexOf(".");
		//从0开始
		String suffixName=originalName.substring(index+1);
		//存在服务器上文件的名字，自己的算法生成	
		return suffixName;
	}
	//获得文件名字
	public String getFileName(MultipartFile file,HttpServletRequest request){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String prefixName=sdf.format(new Date());
		//服务器上存文件的后缀=上传文件的后缀
		//服务器上存储文件的完整 的名字
		String fileName=prefixName+"."+getSuffix(file,request);
		return fileName;
	}
	//获得文件路径
	public String getFilePath(MultipartFile file,HttpServletRequest request){
		//找到上传文件的目录的路径
		String path=request.getSession().getServletContext().getRealPath("/upload");
		//文件的完整路径
		String filePath=path+"/"+getFileName(file,request);
		return filePath;
	}
	//创建文件
	public File getServerFile(MultipartFile file,HttpServletRequest request){
		//把上传的文件存储到服务器
		File serverFile =new File(getFilePath(file,request));
		return serverFile;
	}

	/**
	 * 添加项目
	 * 应用路径 /goods/addGoods.shtml
	 * @param goods
	 * @param request
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/addGoods")
	public String addGoods(
			@ModelAttribute("goods")Goods goods,
			HttpServletRequest request,HttpSession session) throws IOException{
		MultipartHttpServletRequest mrequest=(MultipartHttpServletRequest) request;
		MultipartFile file=mrequest.getFile("file");
		if(!getServerFile(file, mrequest).exists()){
			getServerFile(file, mrequest).createNewFile();
		}
		goods.setGoods_img(base64Encoder(file, getSuffix(file, request)));
		goods.setGoods_filePath(getFilePath(file,request));
		goods.setGoods_fileName(getFileName(file,request));
		User user2=((User)request.getSession().getAttribute(BaseInfo.MERCHANT_SESSION_KEY));
		goods.setGoods_mhtemail(user2.getUser_email());
		goods.setGoods_user_id(user2.getUser_id());
		ig.add(goods);
		return "redirect:getAllGoods.shtml";
	}
	/**
	 * 获取所有项目
	 * 应用路径/goods/getAllGoods.shtml
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/getAllGoods")
	public ModelAndView getAllGoods(HttpServletRequest request) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");
		for (Goods goods : ig.queryAll()) {		
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
			total++;
		}
		mav.addObject("goodslist",ig.queryAll());
		mav.addObject("total",total);
		mav.setViewName("bg-goods-list");
		return mav;
	}

	/**
	 * 获取商户发布的项目信息
	 * 应用路径：/goods/getAllGoodsByUserId.shtml
	 * @param request
	 * @param user_id
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/getAllGoodsByUserId")
	public ModelAndView getAllGoodsByUserId(HttpServletRequest request,
			@RequestParam("user_id")int user_id) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");
		for (Goods goods : ig.queryAllByUserId(user_id)) {		
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
			total++;
		}
		mav.addObject("goodslist",ig.queryAllByUserId(user_id));
		mav.addObject("total",total);
		mav.setViewName("bg-goods-list");
		return mav;
	}
	/**
	 * 按项目名字查询项目信息
	 * 应用路径:/goods/searchBystr.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/searchBystr")
	public ModelAndView searchBystr(HttpServletRequest request
			,@ModelAttribute("goods")Goods goodsM) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Goods goods : ig.searchBystr(goodsM.getGoods_name())) {
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
			total++;
		}
		mav.addObject("goodslist",ig.searchBystr(goodsM.getGoods_name()));
		mav.addObject("total",total);
		mav.addObject("str",goodsM.getGoods_name());
		mav.setViewName("bg-goods-list");
		return mav;
	}

	/**
	 * 输出项目信息到前台界面
	 * 应用路径:/goods/getAllGoodsToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping("/getAllGoodsToIndex")
	public ModelAndView getAllGoodsToIndex(HttpServletRequest request) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Goods goods : ig.queryAll()) {
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
			total++;
		}
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		mav.addObject("list",ig.queryAll());
		mav.addObject("total",total);
		mav.setViewName("goods-list");
		return mav;
	}

	/**
	 * 按种类输出商品信息到前台界面
	 * 应用路径:/goods/getGoodsByKindsToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/getGoodsByKindsToIndex",method=RequestMethod.GET)
	public ModelAndView getGoodsByKindsToIndex(HttpServletRequest request
			,@RequestParam(value="goods_kinds",required=false)int goods_kinds) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Goods goods : ig.queryByKinds(goods_kinds)) {
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
			total++;
		}
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		mav.addObject("list",ig.queryByKinds(goods_kinds));
		mav.addObject("total",total);

		mav.setViewName("goods-list");
		return mav;
	}
	/**
	 * 输出搜索内容到前台页面
	 * 应用路径:/goods/searchBystrToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/searchBystrToIndex")
	public ModelAndView searchBystrToIndex(HttpServletRequest request
			,@ModelAttribute("goods")Goods goodsM) throws IOException{
		ModelAndView mav=new ModelAndView();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Goods goods : ig.searchBystr(goodsM.getGoods_name())) {
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
			total++;
		}
		mav.addObject("list",ig.searchBystr(goodsM.getGoods_name()));
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		mav.addObject("total",total);
		mav.addObject("str",goodsM.getGoods_name());
		mav.setViewName("goods-list");
		return mav;
	}
	@RequestMapping(value="/page",method=RequestMethod.GET)
	public ModelAndView page(HttpServletRequest request
			,@RequestParam(value="page",required=false)int page) throws IOException{
		ModelAndView mav=new ModelAndView();
		int pageRowMax=2;
		int total=0;
		for (Goods goods : ig.queryAll()) {
			total++;
		}
		mav.addObject("goodslist",ig.pageAll(page,pageRowMax));
		mav.addObject("total",total);
		mav.setViewName("bg-goods-list");	
		return mav;
	}
	/**
	 * 更新项目信息
	 * 应用路径：/goods/updateGoods.shtml
	 * @param request
	 * @param article
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/updateGoods")
	public String updateGoods(HttpServletRequest request
			,@ModelAttribute("goods")Goods goods,HttpSession session		
			) throws IOException{
		MultipartHttpServletRequest mrequest=(MultipartHttpServletRequest) request;
		MultipartFile file=mrequest.getFile("file");
		if(!getServerFile(file, mrequest).exists()){
			getServerFile(file, mrequest).createNewFile();
		}
		goods.setGoods_img(base64Encoder(file, getSuffix(file, request)));
		goods.setGoods_filePath(getFilePath(file,request));
		goods.setGoods_fileName(getFileName(file,request));
		//		System.out.println(article);
		ig.update(goods);
		return "redirect:getAllGoods.shtml";
	}
	/**
	 * 按id查询项目信息
	 * 应用路径:/goods/getGoodsById.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/getGoodsById",method=RequestMethod.GET)
	public ModelAndView getGoodsById(HttpServletRequest request
			,@RequestParam(value="goods_id",required=false)int goods_id) throws IOException{
		ModelAndView mav=new ModelAndView();	
		mav.addObject("drByIdList",ig.searchById(goods_id));	
		mav.setViewName("update-goods");
		return mav;
	}
	/**
	 * 删除项目
	 * 应用路径:/goods/deleteGoods.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/deleteGoods",method=RequestMethod.GET)
	public String deleteGoods(
			@RequestParam(value="goods_id",required=false)int goods_id) throws IOException{	
		ig.delete(goods_id);	
		return "redirect:getAllGoods.shtml";
	}
	@RequestMapping(value="/getGoodsDetail",method=RequestMethod.GET)
	public ModelAndView getGoodsDetail(HttpServletRequest request,
			@RequestParam(value="goods_id",required=false)int goods_id
			){
		ModelAndView mav=new ModelAndView();
		Goods goods=ig.searchById(goods_id);
		String conprifix="<pre style='font-size: 20px;background-color: white;color: rgb(47, 79, 79);margin:0;padding:0;'>";
		String consuffix="</pre>";
		String content=conprifix+goods.getGoods_msg()+consuffix; 
		User user2=((User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY));

		try {
			User user3=iu.searchName(user2.getUser_email());
			if(user3!=null){
				mav.addObject("user",user3);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}	
		goods.setGoods_msg(content);	
		mav.addObject("list",goods);
		mav.setViewName("goods-detail");		
		return mav;
	}
	/**
	 * 输出查询内容到前台
	 * 输出搜索内容到前台页面
	 * 应用路径:/goods/searchBystrToIndex.shtml
	 * @throws IOException 
	 * 
	 */
	@RequestMapping(value="/searchAllBystrToIndex")
	public ModelAndView searchAllBystrToIndex(HttpServletRequest request
			,String  str) throws IOException{
		ModelAndView mav=new ModelAndView();
		BASE64Decoder decoder=new BASE64Decoder();
		int total=0;
		String path=request.getSession().getServletContext().getRealPath("/upload");	
		for (Goods goods : ig.searchBystr(str)) {
			int index=goods.getGoods_fileName().lastIndexOf(".");	
			String suffixName=goods.getGoods_fileName().substring(index+1);
			String fileName=goods.getGoods_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			base64Decoder(goods, suffixName, serverFile);
			total++;
		}
		for (Article article : ia.searchBystr(str)) {
			int index=article.getAr_fileName().lastIndexOf(".");	
			String suffixName=article.getAr_fileName().substring(index+1);
			String fileName=article.getAr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			byte[] bytes1 = decoder.decodeBuffer(article.getAr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
			total++;
		}
		for (Drug drug : id.searchBystr(str)) {
			int index=drug.getDr_fileName().lastIndexOf(".");	
			String suffixName=drug.getDr_fileName().substring(index+1);
			String fileName=drug.getDr_fileName();
			String filePath=path+"/"+fileName;
			File serverFile =new File(filePath);
			byte[] bytes1 = decoder.decodeBuffer(drug.getDr_img());   
			ByteArrayInputStream bais = new ByteArrayInputStream(bytes1);   
			BufferedImage bi1 =ImageIO.read(bais);   
			ImageIO.write(bi1, suffixName, serverFile);//不管输出什么格式图片，此处不需改动
			total++;
		}
		mav.addObject("list1",ig.searchBystr(str));
		mav.addObject("list2",ia.searchBystr(str));
		mav.addObject("list3",id.searchBystr(str));
		mav.addObject("str", str);
		User user=(User)request.getSession().getAttribute(BaseInfo.USER_SESSION_KEY);
		try {
			User userM=(User)iu.searchName(user.getUser_email());
			if(userM!=null){
				mav.addObject("user",userM);

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		mav.addObject("total",total);
		mav.setViewName("searchall-list");
		return mav;
	}
}
