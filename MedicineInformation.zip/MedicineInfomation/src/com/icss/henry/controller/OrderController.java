package com.icss.henry.controller;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.icss.henry.dao.IGoods;
import com.icss.henry.dao.IOrder;
import com.icss.henry.dao.IUser;
import com.icss.henry.vo.Goods;
import com.icss.henry.vo.Order;

/**
 * 订单管理
 * @author 陈志伟
 *2016年9月24日
 */
@Controller
@RequestMapping("/order")
public class OrderController {
	@Resource
	IGoods ig;
	@Resource
	IOrder io;
	@Resource 
	IUser iu;
	private int goods_sale=0;
	/**
	 * 添加订单
	 * 用用路径:/order/addOrder.shtml
	 * @param request
	 * @param order
	 * @return
	 */
	@RequestMapping("/addOrder")
	public ModelAndView addOrder(HttpServletRequest request,
			@ModelAttribute("order") Order order){
				ModelAndView mav=new ModelAndView();
				SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String time=sdf.format(new Date());
				order.setOrder_time(time);
				DecimalFormat df = new DecimalFormat("0.00");
				order.setOrder_money(Float.valueOf(df.format(order.getGoods_price()*order.getGoods_buynum())));
				io.add(order);
				mav.addObject("order",order);
				mav.setViewName("paybill");
				return mav;
	}
	/**
	 * 获取所有订单
	 * @param request
	 * @return
	 */
	@RequestMapping("/getAllOrder")
	public ModelAndView getAllOrder(HttpServletRequest request){
		int total=0;
		ModelAndView mav=new ModelAndView();
		for (Order order : io.queryAll()) {
			total++;
		}
		mav.addObject("order",io.queryAll());
		mav.setViewName("bg-order-list");
		mav.addObject("total",total);
		return mav;
	}
	/**
	 * 按商户已发布项目搜索所有订单
	 * @param request
	 * @param user_id
	 * @return
	 */
	@RequestMapping("/getAllOrderByMerchantId")
	public ModelAndView getAllOrderByMerchantId(HttpServletRequest request
			,@RequestParam("user_id")int user_id){
		int total=0;
		ModelAndView mav=new ModelAndView();
		for (Order order : io.queryAllByMerchantId(user_id)) {
			total++;
		}
		mav.addObject("order",io.queryAllByMerchantId(user_id));
		mav.setViewName("bg-order-list");
		mav.addObject("total",total);
		return mav;
	}
	/**
	 * 更新订单
	 * @param order
	 * @return
	 */
	@RequestMapping("updateOrder")
	public String updateOrder(
			@RequestAttribute("order")Order order){
		io.update(order);
		return "redirect:getAllOrder.shtml";
	}
	/**
	 * 按id搜索订单
	 * @param order_id
	 * @return
	 */
	@RequestMapping("/searchOrderById")
	public ModelAndView searchOrderById(
			@RequestParam(value="order_id")int order_id){
		ModelAndView mav=new ModelAndView();
		mav.addObject("order",io.searchById(order_id));
		mav.setViewName("update-order");
		return mav;
	}
	/**
	 * 按id删除订单
	 * @param order_id
	 * @return
	 */
	@RequestMapping("/deleteOrderById")
	public String deleteOrderById(
			@RequestParam(value="order_id")int order_id){
		io.delete(order_id);
		return "redirect:getAllOrder.shtml";
	}
	/**
	 * 搜索订单内容
	 * @param order_str
	 * @return
	 */
	@RequestMapping("/searchByStr")
	public ModelAndView searchByStr(
			@RequestParam(value="order_str")String order_str){
		int total=0;
		ModelAndView mav=new ModelAndView();
		for (Order order : io.searchBystr(order_str)) {
			total++;
		}
		mav.addObject("order",io.searchBystr(order_str));
		mav.setViewName("bg-order-list");
		mav.addObject("total",total);
		mav.addObject("str",order_str);
		//System.out.println(order_str);
		return mav;
	}
	/**
	 * 更新订单信息
	 * @param order_state
	 * @param order_id
	 * @return
	 */
	@RequestMapping("/updateOrderState")
	public String updateOrderState(
			@RequestParam(value="order_state")boolean order_state,
			@RequestParam(value="order_id")int order_id){
			Order order =io.searchById(order_id);
			order.setOrder_state(order_state);
			io.update(order);
		return "redirect:getAllOrder.shtml";
	}
	/**
	 * 付款
	 * @param user_id
	 * @param goods_id
	 * @param goods_buynum
	 * @return
	 */
	@RequestMapping("/payBill")
	public ModelAndView payBill(
			@RequestParam("user_id")int user_id,
			@RequestParam("goods_id")int goods_id,
			@RequestParam("goods_buynum")int goods_buynum){
		Order order=new Order();
		order.setGoods_id(goods_id);
		order.setUser_id(user_id);
		Goods goods=ig.searchById(goods_id);
		goods_sale=goods.getGoods_sale()+goods_buynum;
		io.updateSale(goods_sale, goods_id);
		ModelAndView mav=new ModelAndView();
		mav.addObject("order",order);
		mav.setViewName("comment");
		return mav;
	}
}
